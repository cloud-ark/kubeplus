#!/bin/bash -x

while [ True ]
do
   sleep 100
done