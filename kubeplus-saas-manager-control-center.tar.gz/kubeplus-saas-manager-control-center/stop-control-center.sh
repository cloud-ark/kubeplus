#!/bin/bash

op=`tail -1 ~/.kubeplus/monitoring-container.txt | xargs docker stop`
op=`tail -1 ~/.kubeplus/monitoring-container.txt | xargs docker rm`

ppid=`more ~/.kubeplus/portal.pid`
pgrp=`ps  xao pid,ppid,pgid,comm | grep $ppid | awk '{print $3}' | head -1`
kill -TERM -- -$pgrp
