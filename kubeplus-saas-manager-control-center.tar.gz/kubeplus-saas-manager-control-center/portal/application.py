# Reference: https://realpython.com/flask-google-login/#openid-connect-details

# Python standard libraries
import json
import os
from os.path import exists
import sqlite3

import _thread
import threading
from multiprocessing import Process

import time
import re

from logging.config import dictConfig

# Third-party libraries
from flask import Flask, redirect, request, url_for
from flask_login import (
    LoginManager,
    current_user,
    login_required,
    login_user,
    logout_user,
)
from oauthlib.oauth2 import WebApplicationClient
import requests

# Internal imports
from db import init_db_command
from user import User

from flask import request
from flask import Flask, render_template

from jinja2 import Template

import subprocess
from urllib.parse import unquote
from urllib.parse import urlencode

import db

from werkzeug.utils import secure_filename

UPLOAD_FOLDER = os.getenv('HOME') + '/.kubeplus/charts'


def run_command(cmd):
    app.logger.info(cmd)
    proc_out = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True).communicate()
    out = proc_out[0]
    err = proc_out[1]
    out = out.decode('utf-8')
    err = err.decode('utf-8')
    return out, err

ALLOWED_EXTENSIONS = {'tgz'}

# Configuration
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", None)
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", None)
GOOGLE_DISCOVERY_URL = (
    "https://accounts.google.com/.well-known/openid-configuration"
)


dictConfig({
    'version': 1,
    'formatters': {'default': {
        'format': '[%(asctime)s] %(levelname)s in %(module)s: %(message)s',
    }},
    'handlers': {'wsgi': {
        'class': 'logging.StreamHandler',
        'stream': 'ext://flask.logging.wsgi_errors_stream',
        'formatter': 'default'
    }},
    'root': {
        'level': 'INFO',
        'handlers': ['wsgi']
    }
})

application = Flask(__name__)
app = application
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Flask app setup
#app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(24)

# User session management setup
# https://flask-login.readthedocs.io/en/latest
login_manager = LoginManager()
login_manager.init_app(app)

# Flask-Login helper to retrieve a user from our db
@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

# Naive database setup
try:
    db.init_app(app)
except sqlite3.OperationalError:
#    # Assume it's already been created
    pass

class OrgMonitor(threading.Thread):

    def __init__(self):
        pass

    def _run_command(self, cmd):
        app.logger.info("%s",cmd)
        proc_out = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True).communicate()
        out = proc_out[0]
        err = proc_out[1]
        #print(out)
        #print(err)
        out = out.decode('utf-8')
        err = err.decode('utf-8')
        return out, err

    def _scanOrganizations(self):
            app.logger.info("Inside _scanOrganizations")
            orgList = []
            home = os.getenv("HOME")
            app.logger.info("Home:%s", home)

            kubeplusDir = home + "/.kubeplus"
            directoryToScan = kubeplusDir
            cmd = 'ls -ltr ' + directoryToScan
            out = self._run_command(cmd)
            #print('---')
            #print(out)
            #print('---')
            for line in out:
                #print("line:" + line)
                for line1 in line.split("\n"):
                    if 'total' not in line1 and line1.startswith("d"):
                        line2 = re.sub(' +', ' ', line1)
                        parts = line2.split()
                        if len(parts) > 0:
                            lastPart = parts[len(parts)-1].strip()
                            if lastPart.startswith("org-"):
                                orgNameParts = lastPart.split("-");
                                orgName = orgNameParts[1].strip()
                                if orgName != '':
                                    orgList.append(orgName)
            app.logger.info("Org list:")
            app.logger.info(orgList)
            return orgList

    def run(self):
        app.logger.info("Org Monitor called.")
        while True:
            orgs = self._scanOrganizations()
            home = os.getenv("HOME")
            path = os.getenv("PATH")
            app.logger.info("Home:%s", home)
            app.logger.info("Path:%s", path)

            cmd_outputs = []
            for org in orgs:
                app.logger.info("Org:%s", org)
                kubeconfigPath = home + "/.kubeplus/org-" + org + '/config'
                cmd_to_run = 'kubectl monitor org allservices ' + org

                out, err = self._run_command(cmd_to_run)
                cmd_output = out
                if err != '':
                    cmd_output = err
                app.logger.info(cmd_output)
                cmd_outputs.append(cmd_output)
            output = {}
            output['output'] = cmd_outputs
            obj_to_ret = json.dumps(output)
            app.logger.info('---')
            app.logger.info(obj_to_ret)
            time.sleep(180) # wait for three minutes

#def start_thread(org_monitor_thread):
#    try:
#        org_monitor_thread.run()
#    except Exception as e:
#        app.logger.info(e)

# Thread based approach
#_thread.start_new_thread(start_thread, (org_monitor_thread, ))

# OAuth 2 client setup
client = WebApplicationClient(GOOGLE_CLIENT_ID)

# Control center settings
settings = {}


def get_google_provider_cfg():
    return requests.get(GOOGLE_DISCOVERY_URL).json()


def get_all_services():
    cmd = 'kubectl list services '
    out, err = run_command(cmd)
    service_list = []
    if out != '' and err == '':
        for line in out.split("\n"):
            line = line.strip()
            if line != '':
                service_list.append(line)
    app.logger.info(service_list)
    service_list_ret = []
    for service in service_list:
        service_data = {}
        service_data['name'] = service
        service_list_ret.append(service_data)

    return service_list_ret


def get_all_organizations():
    cmd = 'kubectl list organizations '
    out, err = run_command(cmd)
    org_list = []
    if out != '' and err == '':
        for line in out.split("\n"):
            line = line.strip()
            if line != '':
                org_list.append(line)
    app.logger.info(org_list)
    org_list_ret = []
    for org in org_list:
        org_data = {}
        org_data['name'] = org
        org_list_ret.append(org_data)

    return org_list_ret

def get_added_services(org):
    home = os.getenv("HOME")
    app.logger.info("Home:%s", home)
    orgPath = home + "/.kubeplus/org-" + org + '/config'
    cmd = 'kubectl get crds --kubeconfig=' + orgPath
    out, err = run_command(cmd)
    service_list = []
    if out != '' and err == '':
        for line in out.split("\n"):
            line = line.strip()
            if line != '':
                if 'platformapi.kubeplus' in line:
                    app.logger.info('Found service:%s', line)
                    parts = line.split(" ")
                    service_list.append(parts[0].strip())
    app.logger.info("Service list:")
    app.logger.info(service_list)
    return service_list

def get_service_details(service):
    cmd = 'kubectl show service ' + service + " --promurl"
    out, err = run_command(cmd)
    if out != '' and err == '':
        return out.strip()

def get_organization_details(org):
    cmd = 'kubectl show organization ' + org
    out, err = run_command(cmd)
    if out != '' and err == '':
        return out

def add_service_to_org(org, serviceToAdd):
    cmd = 'kubectl add service ' + org + ' ' + serviceToAdd
    out, err = run_command(cmd)
    if out != '' and err == '':
        return out
    else:
        return err

def monitor_org_service(org, serviceToAdd):
    cmd = 'kubectl monitor organization ' + org + ' ' + serviceToAdd
    out, err = run_command(cmd)
    if out != '' and err == '':
        return out
    else:
        return err

def get_service_name_plural(serviceNameLower):
    parts = list(serviceNameLower)
    if parts[-1] == 's':
        return serviceNameLower + "es"
    else:
        return serviceNameLower + "s"

def parse_chart_name(artifact):
    artifact_name = artifact
    index = artifact.rfind("/")
    if index > 0:
        artifact_name = artifact[index+1:]
    app.logger.info("Artifact name:%s", artifact_name)

    parts = artifact_name.split("?")
    name_to_ret = parts[0].strip()
    app.logger.info("Artifact name1:%s", name_to_ret)
    return name_to_ret

def save_chart(file, filename):
    if not exists(UPLOAD_FOLDER):
        app.logger.info("Checking if charts upload folder is created or not.")
        kubeplus_home = os.getenv("HOME")

        cmd = "mkdir -p " + UPLOAD_FOLDER
        run_command(cmd)
        cmd_output = out
        if err != '':
            cmd_output = err
        app.logger.info(cmd_output)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

def get_service_instances(org, service):
    app.logger.info("Inside get_service_instances")
    home = os.getenv("HOME")
    app.logger.info("Home:%s", home)
    orgPath = home + "/.kubeplus/org-" + org + '/config'

    cmd = 'kubectl get ' + service + ' -A ' + ' --kubeconfig=' + orgPath
    out, err = run_command(cmd)

    instance_list = []
    if out != '' and err == '':
        for line in out.split("\n"):
            namespace_instance_map = {}
            line1 = re.sub(' +', ' ', line)
            app.logger.info("line1:%s", line1)
            if 'NAMESPACE' not in line1 and line1 != '':
                parts = line1.split()
                namespace_instance_map['NAMESPACE'] = parts[0].strip()
                namespace_instance_map['NAME'] = parts[1].strip()
                instance_list.append(namespace_instance_map)
    return instance_list

def process_manpage_line(line):
    parts = line.split(":")
    part = parts[1].strip()
    return part

def get_input_fields(serviceName):
    cmd = 'kubectl man ' + serviceName
    out, err = run_command(cmd)

    kind = ""
    group = ""
    version = ""
    apiVersion = ""
    fieldList = []
    # invariant we want to maintain - fieldList should not contain namespace
    if out != "":
        lines = out.split("\n")
        specFields = False
        for line in lines:
            app.logger.info(line)
            if "KIND:" in line:
                kind = process_manpage_line(line)
            if "GROUP:" in line:
                group = process_manpage_line(line)
            if "VERSION:" in line:
                version = process_manpage_line(line)
            if specFields:
                parts = line.split(":")
                app.logger.info("LINE:" + line)
                if len(parts) >= 2:
                    field = parts[0].strip()
                    if field != '':
                        fieldList.append(field)
            if "/values.yaml" in line:
                specFields = True

    apiVersion = group + "/" + version
    app.logger.info("kind:" + kind)
    app.logger.info("apiVersion:" + apiVersion)
    app.logger.info("fieldList:" + str(fieldList))
    return kind, apiVersion, fieldList

def get_kind(crd):
    cmd = 'kubectl describe crd ' + crd
    out, err = run_command(cmd)
    kind = ''
    if out != "":
        lines = out.split("\n")
        accepted_names_found = False
        for line in lines:
            line = line.strip()
            app.logger.info(line)
            if accepted_names_found:
                if "Kind:" in line:
                    parts = line.split(":")
                    kind = parts[1].strip()
                    break
            if "Accepted Names:" in line:
                accepted_names_found = True
    app.logger.info("Kind:%s",kind)
    return kind

@app.route("/register_service",methods=['POST'])
@login_required
def register_service():
    app.logger.info("Received request.")
    app.logger.info(request.form)
    serviceName = request.form["serviceName"].strip()
    chartURL = request.form["helm-chart-url"].strip()
    #chartName = request.form["helm-chart-name"].strip()

    if chartURL == '':
        file = request.files['helm-chart-path']

        filename = secure_filename(file.filename)
        filename = filename.strip()
        app.logger.info("File Name:%s", filename)
        save_chart(file, filename)

        chartName = parse_chart_name(filename)
        chartURL = "file:///" + filename
    else:
        chartName = parse_chart_name(chartURL)

    app.logger.info("ServiceName:%s", serviceName)
    app.logger.info("Chart Name:%s", chartName)
    app.logger.info("Chart URL:%s", chartURL)

    serviceNameLower = serviceName.lower()
    serviceNamePlural = get_service_name_plural(serviceNameLower)
    app.logger.info("Service Name Lower:%s", serviceNameLower)
    app.logger.info("Service Name Plural:%s", serviceNamePlural)

    fp = open("./ResourceCompositionTemplate.yaml","r")
    contents = fp.read()
    t = Template(contents)
    serviceResComposition = t.render(serviceName=serviceName,
                                     serviceNameLower=serviceNameLower,
                                     serviceNamePlural=serviceNamePlural,
                                     chartURL=chartURL,
                                     chartName=chartName)

    fp1 = open(serviceName + ".yaml", "w")
    fp1.write(serviceResComposition)
    fp1.close()

    cmd = 'kubectl register service ' + serviceName + ' ./' + serviceName + ".yaml"
    out, err = run_command(cmd)
    instance_creation_status = out
    app.logger.info("Out:%s", out)
    app.logger.info("Err:%s", err)
    if err != '':
        instance_creation_status = err
    service_list = get_all_services()
    org_list = get_all_organizations()

    users_email = current_user.email

    return render_template('welcome.html',
                            name=users_email,
                            service_list=service_list,
                            org_list=org_list,
                            create_status=instance_creation_status,
                            create_status_display='display:block;',
                            show_steps_display='display:none;')


@app.route("/service/<service>")
def get_service(service):
    data = get_service_details(service)
    service_data = {}
    service_data['name'] = service
    service_data['details'] = data
    obj_to_ret = json.dumps(service_data)
    return obj_to_ret



@app.route("/register_organization",methods=['POST'])
@login_required
def register_organization():
    app.logger.info("Received request.")
    app.logger.info(request.form)
    orgName = request.form["orgName"]
    fp = open("./" + orgName + ".yaml", "w")
    providerKubeconfig = request.form["provider-kubeconfig"]
    fp.write(providerKubeconfig)
    fp.close()
    cmd = 'kubectl register organization ' + orgName + ' ./' + orgName + ".yaml"
    out, err = run_command(cmd)
    instance_creation_status = out
    if err != '':
        instance_creation_status = err
    org_list = get_all_organizations()

    service_list = get_all_services()

    users_email = current_user.email

    return render_template('welcome.html',
                            name=users_email,
                            service_list=service_list,
                            org_list=org_list,
                            create_status=instance_creation_status,
                            create_status_display='display:block;',
                            show_steps_display='display:none;')


@app.route("/add_service_to_organization",methods=['POST'])
@login_required
def add_service_to_organization():
    app.logger.info("Received request.")
    app.logger.info(request.form)
    serviceToAdd = request.form['available-services']
    org = request.form.get('org')
    app.logger.info("Service:" + serviceToAdd)
    app.logger.info("Organization:" + org)

    add_status = add_service_to_org(org, serviceToAdd)
    status = add_status
    org_list = get_all_organizations()
    service_list = get_all_services()

    app.logger.info(current_user)
    app.logger.info("-----")
    users_email = current_user.email
    app.logger.info(users_email)

    return render_template('welcome.html',
                            name=users_email,
                            service_list=service_list,
                            org_list=org_list,
                            create_status=status,
                            create_status_display='display:block;',
                            show_steps_display='display:none;')


@app.route("/organization/<org>")
def get_organization(org):
    data = get_organization_details(org)
    org_data = {}
    org_data['name'] = org
    org_data['kubeconfig'] = data
    availableServices = get_all_services()
    org_data['availableServices'] = []
    for s in availableServices:
        org_data['availableServices'].append(s['name'].strip())
    org_data['addedServices'] = get_added_services(org)

    service_instance_map = {}
    for addedService in org_data['addedServices']:
        instance_list = get_service_instances(org, addedService)
        service_instance_map[addedService] = instance_list
    org_data['serviceInstances'] = service_instance_map
    obj_to_ret = json.dumps(org_data)
    app.logger.info(obj_to_ret)
    return obj_to_ret


@app.route("/organization/command")
@login_required
def get_cmd_output():
    cmd = request.args.get('cmd').strip()
    org = request.args.get('org').strip()

    app.logger.info("Cmd:%s", cmd)
    app.logger.info("Org:%s", org)
    command = unquote(cmd)
    app.logger.info("Command:%s", command)

    home = os.getenv("HOME")
    app.logger.info("Home:%s", home)
    kubeconfigPath = home + "/.kubeplus/org-" + org + '/config'

    cmd_to_run = command + ' --kubeconfig=' + kubeconfigPath

    out, err = run_command(cmd_to_run)
    cmd_output = out
    if err != '':
        cmd_output = err

    app.logger.info(cmd_output)
    output = {}
    output['output'] = cmd_output
    obj_to_ret = json.dumps(output)
    app.logger.info('---')
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/fetch_current_settings")
def fetch_current_settings():
    app.logger.info("Inside fetch_current_settings")

    home = os.getenv("HOME")
    app.logger.info("Home:%s", home)
    settingsFilePath = home + "/.kubeplus/settings.txt"
    settings = {}
    if exists(settingsFilePath):
        fp = open(settingsFilePath, "r")
        obj = fp.read()
        json_obj = json.loads(obj)
        app.logger.info(json_obj)
        settings["webhook"] = json_obj["webhook"]
        settings["channel"] = json_obj["channel"]
    else:
        # Example values
        #settings["webhook"] = "https://hooks.slack.com/services/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"
        #settings["channel"] = "#kubeplus-alerts"
        settings["webhook"] = ""
        settings["channel"] = ""
    obj_to_ret = json.dumps(settings)
    app.logger.info('---')
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/set_new_settings",methods=['PUT'])
def set_new_settings():
    app.logger.info("Inside set_new_settings")

    wbhk = request.args.get('webhook').strip()
    chnl = request.args.get('channel').strip()

    webhook = unquote(wbhk)
    channel = unquote(chnl)

    app.logger.info("Webhook:%s", wbhk)
    app.logger.info("Channel:%s",chnl)

    settings["webhook"] = webhook
    settings["channel"] = channel

    obj_to_ret = json.dumps(settings)

    home = os.getenv("HOME")
    settingsFilePath = home + "/.kubeplus/settings.txt"
    fp = open(settingsFilePath, "w")
    fp.write(obj_to_ret)
    fp.close()

    cmd_to_run = "kubectl setslackalerts " + webhook + " \"" + channel + "\""

    out, err = run_command(cmd_to_run)
    cmd_output = out
    if err != '':
        cmd_output = err

    app.logger.info(cmd_output)
    output = {}
    output['output'] = cmd_output
    obj_to_ret = json.dumps(output)
    app.logger.info('---')
    app.logger.info(obj_to_ret)

    return obj_to_ret

@app.route("/create_service_instance",methods=['POST'])
def create_service_instance():
    app.logger.info("Inside create_service_instance")

    form = request.form
    app.logger.info(form)

    crd = request.form['crd']
    org = request.form['org']

    crd1 = unquote(crd)
    org1 = unquote(org)

    app.logger.info("CRD:%s", crd1)
    app.logger.info("Org:%s", org1)

    canonical_kind_name = get_kind(crd1)
    kind, apiVersion, fields = get_input_fields(canonical_kind_name);

    fieldMap = {}
    for f in fields:
        fieldMap[f] = request.form[f]
    #apiVersion: platformapi.kubeplus/v1alpha1
    #kind: WordpressService 
    #metadata:
    #  name: abc-org-tenant1
    #spec:
    #  namespace: default 
    #  tenantName: tenant1
    #  nodeName: gke-abc-org-default-pool-d0114ae7-0dl9

    res = {}
    res["apiVersion"] = apiVersion
    res["kind"] = canonical_kind_name
    metadata = {}
    resName = request.form["name"]
    namespace = "default"
    metadata["name"] = resName
    res["metadata"] = metadata
    #if 'namespace' in fieldMap:
    #   namespace = fieldMap["namespace"]
    metadata["namespace"] = namespace
    spec = {}
    for k,v in fieldMap.items():
        spec[k] = v
    res["spec"] = spec

    home = os.getenv("HOME")
    app.logger.info("Home:%s",home)
    org_home = home + "/.kubeplus/org-" + org1

    fp = open(org_home + "/resource.json","w")
    fp.write(json.dumps(res))
    fp.close()

    cmd = 'kubectl create -f ' + org_home + '/resource.json '
    out, err = run_command(cmd)
    app.logger.info("Output:%s",out)
    app.logger.info("Error:%s",err)

    instance_creation_status = out
    if err != '':
        instance_creation_status = err

    service_list = get_all_services()
    org_list = get_all_organizations()

    #users_email = current_user.email
    users_email = 'abc'

    return render_template('welcome.html',
                            name=users_email,
                            service_list=service_list,
                            org_list=org_list,
                            create_status=instance_creation_status,
                            create_status_display='display:block;',
                            show_steps_display='display:none;')


@app.route("/field_names")
def get_field_names():
    app.logger.info("Inside get_field_names")
    quoted_crd = request.args.get('crd').strip()
    crd = unquote(quoted_crd)
    canonical_kind_name = get_kind(crd)

    fields = []
    kind, apiVersion, fields = get_input_fields(canonical_kind_name)

    # the name of the resource needs to be input as well.
    if 'name' not in fields:
        fields.insert(0,"name") 
    fields_dict = {}
    fields_dict["fields"] = fields
    obj_to_ret = json.dumps(fields_dict)
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/organization/monitor")
def monitor_orgs():
    orgList = request.args.get('orgs').strip()
    orgs = orgList.split(",")
    cmd_outputs = []
    for org in orgs:
        app.logger.info("Org:%s", org)

        home = os.getenv("HOME")
        app.logger.info("Home:%s", home)
        kubeconfigPath = home + "/.kubeplus/org-" + org + '/config'

        cmd_to_run = 'kubectl monitor org allservices ' + org

        out, err = run_command(cmd_to_run)
        cmd_output = out
        if err != '':
            cmd_output = err
        app.logger.info(cmd_output)
        cmd_outputs.append(cmd_output)
    output = {}
    output['output'] = cmd_outputs
    obj_to_ret = json.dumps(output)
    app.logger.info('---')
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/logout",methods=['GET'])
@login_required
def logout():
    app.logger.info("Logout called.")
    logout_user()
    #return redirect(url_for("index"))
    app.logger.info("Before returning...")
    return render_template('index.html')


@app.route("/login/callback")
def callback():
    # Get authorization code Google sent back to you
    code = request.args.get("code")

    # Find out what URL to hit to get tokens that allow you to ask for
    # things on behalf of a user
    google_provider_cfg = get_google_provider_cfg()
    token_endpoint = google_provider_cfg["token_endpoint"]

    # Prepare and send a request to get tokens! Yay tokens!
    token_url, headers, body = client.prepare_token_request(
        token_endpoint,
        authorization_response=request.url,
        redirect_url=request.base_url,
        code=code
    )
    token_response = requests.post(
        token_url,
        headers=headers,
        data=body,
        auth=(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET),
    )

    # Parse the tokens!
    client.parse_request_body_response(json.dumps(token_response.json()))

    # Now that you have tokens (yay) let's find and hit the URL
    # from Google that gives you the user's profile information,
    # including their Google profile image and email
    userinfo_endpoint = google_provider_cfg["userinfo_endpoint"]
    uri, headers, body = client.add_token(userinfo_endpoint)
    userinfo_response = requests.get(uri, headers=headers, data=body)

    # You want to make sure their email is verified.
    # The user authenticated with Google, authorized your
    # app, and now you've verified their email through Google!
    if userinfo_response.json().get("email_verified"):
        unique_id = userinfo_response.json()["sub"]
        users_email = userinfo_response.json()["email"]
        picture = userinfo_response.json()["picture"]
        users_name = userinfo_response.json()["given_name"]
    else:
        return "User email not available or not verified by Google.", 400

    # Create a user in your db with the information provided
    # by Google
    user = User(
        id_=unique_id, name=users_name, email=users_email, profile_pic=picture
    )

    # Doesn't exist? Add it to the database.
    if not User.get(unique_id):
        User.create(unique_id, users_name, users_email, picture)

    # Begin user session by logging the user in
    login_user(user)

    service_list = get_all_services()

    org_list = get_all_organizations()

    # Send user back to homepage
    return render_template('welcome.html',
        name=users_email,
        service_list=service_list,
        org_list=org_list,
        form_display="none",
        create_status_display="none")
    #return redirect(url_for("welcome"))


@app.route("/login1", methods=['POST'])
def login_google():
	# Find out what URL to hit for Google login
    google_provider_cfg = get_google_provider_cfg()
    authorization_endpoint = google_provider_cfg["authorization_endpoint"]

    # Use library to construct the request for Google login and provide
    # scopes that let you retrieve user's profile from Google
    request_uri = client.prepare_request_uri(
        authorization_endpoint,
        redirect_uri=request.base_url + "/callback",
        scope=["openid", "email", "profile"],
    )
    return redirect(request_uri)

def verify_user(username, password):
    home = os.getenv("HOME")
    app.logger.info("Home:%s",home)
    kubeplusCreds = home + "/.kubeplus/creds"
    fp = open(kubeplusCreds, "r")
    lines = fp.readlines()
    for line in lines:
        parts = line.strip().split(":")
        configured_user = parts[0].strip()
        configured_password = parts[1].strip()
        if username == configured_user and password == configured_password:
            return True
    return False

def get_app_url(resource, instance, namespace, org):
    hyphenatedOrg = 'org-' + org
    app.logger.info("Hyphenated Org:%s", hyphenatedOrg)
    kubeplusHome = os.getenv('HOME') + "/.kubeplus"
    org_kubeconfig = kubeplusHome + "/" + hyphenatedOrg + "/config"

    

    cmd = 'kubectl appurl ' + resource + ' ' + instance + ' ' + namespace + ' -k ' + org_kubeconfig
    out, err = run_command(cmd)
    data = ''
    if out != '' and err == '':
        print(out)
        out = out.strip()
    return out

def get_logs(resource, instance, namespace):
    cmd = 'kubectl applogs ' + resource + ' ' + instance + ' ' + namespace 
    out, err = run_command(cmd)
    data = ''
    if out != '' and err == '':
        print(out)
        out = out.strip()
    return out

def get_connections_op(org, service, instance, namespace):
    app.logger.info("Inside get_connections_op")
    hyphenatedOrg = 'org-' + org
    app.logger.info("Hyphenated Org:%s", hyphenatedOrg)
    kubeplusHome = os.getenv('HOME') + "/.kubeplus"
    cmd = 'kubectl connections ' + service + ' ' + instance + ' ' + namespace + ' -o html -n label,specproperty,annotation'
    cmd = cmd + " -k " + kubeplusHome + '/' + hyphenatedOrg + "/config"
    app.logger.info("Connections cmd:%s", cmd)

    out, err = run_command(cmd)
    cmd_output = out
    if err != '':
        cmd_output = err
    file_path = cmd_output.split(":")[1].strip()
    app.logger.info("File path:%s", file_path)

    fp = open(file_path, "r")
    data = fp.read()
    return data

@app.route("/resource_details",methods=['GET'])
@login_required
def get_resource_details():
    app.logger.info("Inside get_resource_details.")
    org = request.args.get('org').strip()
    service = request.args.get('service').strip()
    instance = request.args.get('instance').strip()
    namespace = request.args.get('namespace').strip()

    app.logger.info("Org:%s, Service:%s, Instance:%s, Namespace:%s", org, service, instance, namespace)

    topology_data = get_connections_op(org, service, instance, namespace)
    logs_data = get_logs(service, instance, namespace)
    app_url = get_app_url(service, instance, namespace, org)

    output = {}
    output['topology'] = topology_data
    output['logs'] = logs_data
    output['app_url'] = app_url

    obj_to_ret = json.dumps(output)
    app.logger.info('---')
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/topology",methods=['GET'])
@login_required
def get_topology():
    app.logger.info("Inside get_topology.")
    org = request.args.get('org').strip()
    service = request.args.get('service').strip()
    instance = request.args.get('instance').strip()
    namespace = request.args.get('namespace').strip()

    app.logger.info("Org:%s, Service:%s, Instance:%s, Namespace:%s", org, service, instance, namespace)
    data = get_connections_op(org, service, instance, namespace)

    output = {}
    output['topology'] = data

    obj_to_ret = json.dumps(output)
    app.logger.info('---')
    app.logger.info(obj_to_ret)
    return obj_to_ret

@app.route("/login", methods=['POST'])
def login():
    username = request.form['username'].strip()
    password = request.form['password'].strip()
    app.logger.info("Username:%s", username)
    app.logger.info("Password:%s", password)

    verified = verify_user(username, password)
    if not verified:
        return render_template('unauthorized.html')

    # Create a user in your db with the information provided
    user = User(
        id_=username, name=username, email=username, profile_pic=username
    )

    # Doesn't exist? Add it to the database.
    if not User.get(username):
        User.create(username, username, username, username)

    # Begin user session by logging the user in
    login_user(user)

    service_list = get_all_services()

    org_list = get_all_organizations()

    # Send user back to homepage
    return render_template('welcome.html',
        name=username,
        service_list=service_list,
        org_list=org_list,
        form_display="none",
        create_status_display="none")


@app.route("/")
def index():
    return render_template('index.html')


if __name__ == "__main__":

    org_monitor_thread = OrgMonitor()

    # Start the process to periodically scan the organizations
    # and updates Prometheus jobs for any new service instances
    # that it discovers.
    p = Process(target=org_monitor_thread.run)
    p.start()

    app.debug = True
    app.logger.info('Portal started...')
#   Turning off SSL for now. We will revisit it later.
#    app.run(host='0.0.0.0', port=5002, ssl_context="adhoc")
    app.run(host='0.0.0.0', port=5002)
