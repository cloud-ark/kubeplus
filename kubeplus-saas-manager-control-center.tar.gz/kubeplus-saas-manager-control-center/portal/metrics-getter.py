from flask import Flask
from flask import request
import subprocess
import time
import json

app = Flask(__name__)

def get_metrics(out, millis, kind, customResourceName):
    metricsToReturn = ''
    try:
        json_output = json.loads(out)
        cpu = json_output['cpu'].replace('m', '')
        memory = json_output['memory'].replace('Mi', '')
        storage = json_output['storage'].replace('Gi', '')
        cpuMetrics = 'cpu{kind="'+kind+'",customresoure="' + customResourceName +'"} ' + str(cpu) + ' ' + str(millis)        #print(cpuMetrics)
        memoryMetrics = 'memory{kind="'+kind+'",customresoure="' + customResourceName +'"} ' + str(memory) + ' ' + str(millis)
        #print(memoryMetrics)
        storageMetrics = 'storage{kind="'+kind+'",customresoure="' + customResourceName +'"} ' + str(storage) + ' ' + str(millis)
        metricsToReturn = cpuMetrics + "\n" + memoryMetrics + "\n" + storageMetrics
        #print(metricsToReturn)
    except JSONDecodeError as e:
        print(e)
    return metricsToReturn

def get_metrics1(out, millis, customResourceName):
    cpuMetrics = ''
    memoryMetrics = ''
    metricsToReturn = ''
    out = out.splitlines()
    count = 0
    for line in out:
        count = count + 1
        if count == 2:
            line = str(line)
            print(line)
            parts = line.split(' ')
            print(parts)
            parts1 = [i for i in parts if i]
            print(parts1)
            #podName = str(parts1[0].decode("utf-8"))
            #podName = parts1[0]
            #podName = 'devdatta'
            cpu = parts1[1].replace('m','')
            memory = parts1[2].replace('Mi','')

            cpuMetrics = 'cpu{customresoure="' + customResourceName +'"} ' + str(cpu) + ' ' + str(millis)
            #print(cpuMetrics)
            memoryMetrics = 'memory{customresoure="' + customResourceName +'"} ' + str(memory) + ' ' + str(millis)
            #print(memoryMetrics)
            metricsToReturn = cpuMetrics + "\n" + memoryMetrics + "\n"
            #print(metricsToReturn)
            return metricsToReturn


@app.route('/customresource/metrics')
def custom_resource_metrics():
    kind = request.args.get('kind')
    instance = request.args.get('instance')
    namespace = request.args.get('namespace')
    #print("Kind:" + kind + " instance:" + instance + " namespace:" + namespace)
    listToReturn = []
    millis = int(round(time.time() * 1000))

    process = subprocess.Popen(['kubectl', 'metrics', 'cr', kind, instance, namespace, '-o', 'json'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    metricsToReturn = get_metrics(out, millis, kind, instance)
    print(metricsToReturn)
    return metricsToReturn
    #listToReturn.append(metricsToReturn)

    #returnString = ''
    #for l in listToReturn:
    #	if l != None:
    #		returnString = returnString + l
    #return returnString 


@app.route('/helmrelease/metrics')
def helm_release_metrics():
    helmrelease = request.args.get('helmrelease')
    print("Helm Release:" + helmrelease)
    returnString = ''
    return returnString


@app.route('/service/metrics')
def service_metrics():
    service = request.args.get('service')
    namespace = request.args.get('namespace')
    print("Service:" + service)
    print("Namespace:" + namespace)
    returnString = ''
    return returnString


