function validateData() {
  return true;
}

function get_all_resources(resource){
  //alert("Hello World");
  displayString = "1. abc-org-tenant1 <br> 2. abc-org-tenant2"

  num_of_instances = document.getElementById("num_of_instances");
  num_of_instances.innerHTML = "Calculating...";
  num_of_instances.setAttribute("style", "display:block;");

  cpu = "-";
  memory = "-";
  storage = "-";
  nw_ingress = "-";
  nw_egress = "-";
  set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //Reference: https://stackoverflow.com/questions/33914245/how-to-replace-the-entire-html-webpage-with-ajax-response
        $("html").html(xhttp.responseText);
//        render_resources(this, resource);
    }
  };
  //url = "/getAll?resource=" + resource;
  url = "/service/" + resource
  xhttp.open("GET", url, true);
  xhttp.send();
}

function render_resources(xmlhttp, resource)
{
  data = xmlhttp.responseText;
  console.log(data);
  console.log("-------");
  data1 = JSON.parse(data)
  instances = data1[resource];
  console.log(instances)
  displayString = "";
  count = 1
  for (const val of instances) {
    displayString = displayString + count + ".&nbsp;&nbsp;" + val['name'] + "&nbsp;&nbsp;" + val['namespace'] + "<br>"
    count = count + 1
  }
  element = document.getElementById("service_information_space");
  element.innerHTML = displayString;
}

function get_resource_api_doc(resource){
  displayString = "Here is information about: " + resource
  //alert(displayString);
  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        render_resource_api_doc(this, resource);
    }
  };
  url = "/get_resource_manpage?resource=" + resource;
  xhttp.open("GET", url, true);
  xhttp.send();
}

function render_resource_api_doc(xmlhttp, resource)
{
  data = xmlhttp.responseText;
  console.log(data);
  console.log("-------");
  data1 = JSON.parse(data)
  manPage = data1[resource];
  console.log(manPage)

  //document.getElementById("input-form").style.display = "none";
  //document.getElementById("metrics-details").style.display = "none";

  elementsToHide = ["input-form", "metrics-details","consumption_string_id", "num_of_instances","create-status"];
  hideElements(elementsToHide);

  element = document.getElementById("man-page");
  element.innerHTML = manPage;
  document.getElementById("man-page").style.display = "block";
}

function get_resource(res_string) {

  elementsToHide = ["input-form", "man-page","create-status"];
  hideElements(elementsToHide);

  document.getElementById("metrics-details").style.display = "block";
  document.getElementById("metrics-details").setAttribute("class","table table-condensed table-striped table-bordered");
  document.getElementById("metrics-details").setAttribute("width","100%");

  cpu = "-";
  memory = "-";
  storage = "-";
  nw_ingress = "-";
  nw_egress = "-";
  set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

  num_of_instances = document.getElementById("num_of_instances");
  num_of_instances.innerHTML = "Calculating...";
  num_of_instances.setAttribute("style", "display:block;");

  myArr = res_string.split(",")

  console.log("Name:" + myArr[0]);
  instance = myArr[0];
  namespace = myArr[1];
  resource = myArr[2];
  element = document.getElementById("consumption_string_id");
  element.innerHTML = "Consumption metrics for " + instance;
  element.style.display = "block";

  // TODO: Make Ajax call to get metrics for <instance, namespace, resource>

  url = "/service/instance_data?resource=" + resource + "&instance=" + instance + "&namespace=" + namespace;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData)

        cpu = data1['cpu'];
        memory = data1['memory'];
        storage = data1['storage'];
        nw_ingress = data1['nw_ingress'];
        nw_egress = data1['nw_egress'];
        set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

        app_url = data1['app_url']
        console.log("App URL:" + app_url)
        /*
        // Connections O/P is not relevant for Consumer so no need to display it.
        connections_op = data1['connections_op'];
        document.getElementById("connections_op").innerHTML = connections_op;
        document.getElementById("connections_op").style.display = "block";
        */

        app_url1 = "<hr><a href=\"" + app_url + "\">Application URL</a><hr>"
        document.getElementById("app_url").innerHTML = app_url1;
        document.getElementById("app_url").style.display = "block";

        log_data = data1['logs'];
        console.log(log_data)

        textarea = "<label style=\"font-size:large;\">Application Logs</label><br><p><textarea style=\"overflow:scroll;width:600px;height:200px\">" + log_data + "</p></textarea>";
        document.getElementById("app_logs_data").innerHTML = textarea;
        document.getElementById("app_logs_data").style.display = "block";

        /*
        logs_url = "<a href=\"" + "\">Application Logs</a><hr><br></br>"
        document.getElementById("app_logs_url").innerHTML = logs_url;
        document.getElementById("app_logs_url").style.display = "block";
        document.getElementById("app_logs_url").onclick = get_logs(resource, instance, namespace)
        */

        elementsToHide = ["num_of_instances"];
        hideElements(elementsToHide);
      }
    };
  xhr.send();
}

function get_logs(resource, instance, namespace) {

  url = "/service/instance_logs?resource=" + resource + "&instance=" + instance + "&namespace=" + namespace;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData);
        log_data = data1['logs'];
        console.log(log_data)

        textarea = "<textarea style=\"overflow:scroll;width:300px;height:200px\">" + log_data + "</textarea>";
        document.getElementById("app_logs_data").innerHTML = textarea;
        document.getElementById("app_logs_data").style.display = "block";
      }
    };
  xhr.send();
}

function set_metrics(cpu, memory, storage, ingress, egress) {
  cpuelement = document.getElementById("total_cpu");
  cpuelement.innerHTML = cpu + "<br> (millicores)";

  memelement = document.getElementById("total_memory");
  memelement.innerHTML = memory + "<br> (mebibytes)" ;

  storageelement = document.getElementById("total_storage");
  storageelement.innerHTML = storage + "<br> (Giga bytes)" ;

  ingresselement = document.getElementById("total_nw_ingress");
  ingresselement.innerHTML = nw_ingress + "<br> (bytes)" ;

  egresselement = document.getElementById("total_nw_egress");
  egresselement.innerHTML = nw_egress + "<br> (bytes)" ;
}

function create_form_organization() {

  // Will not be using this static form going forward;
  document.getElementById("input-form-organization").style.display = "none";

  // Hide the info panel
  document.getElementById("entity-details").style.display = "none";

  entityFormContainer = document.getElementById("entity-form-container");
  var entityForm = document.createElement("div");
  entityForm.setAttribute("class", "form-popup");
  entityForm.setAttribute("id", "input-form-entity");
  entityForm.setAttribute("style", "display:block;");
  entityFormContainer.appendChild(entityForm);

  deleteElement("form-details");

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  var formBody = document.createElement("form");
  formBody.setAttribute("class", "form-container");
  formBody.setAttribute("action", "register_organization");
  formBody.setAttribute("method", "post");
  formBody.setAttribute("id", "form-details");
  entityForm.appendChild(formBody);

  var brk1 = document.createElement("br");
  formBody.appendChild(brk1);

  var orgNameLabel = document.createElement("label");
  orgNameLabel.innerHTML = "Organization name";
  orgNameLabel.setAttribute("for","orgName");
  orgNameLabel.setAttribute("class", "labelfont");
  formBody.appendChild(orgNameLabel);

  var brk2 = document.createElement("br");
  formBody.appendChild(brk2);

  var orgNameInput = document.createElement("input");
  orgNameInput.setAttribute("type", "text");
  orgNameInput.setAttribute("id", "orgName");
  orgNameInput.setAttribute("name", "orgName");
  formBody.appendChild(orgNameInput);

  var brk3 = document.createElement("br");
  formBody.appendChild(brk3);

  var providerKubeconfigLabel = document.createElement("label");
  providerKubeconfigLabel.innerHTML = "Provider Kubeconfig";
  providerKubeconfigLabel.setAttribute("for","provider-kubeconfig");
  providerKubeconfigLabel.setAttribute("class", "labelfont");
  formBody.appendChild(providerKubeconfigLabel);

  var brk4 = document.createElement("br");
  formBody.appendChild(brk4);

  var providerKubecfg = document.createElement("textarea");
  providerKubecfg.setAttribute("id", "provider-kubeconfig");
  providerKubecfg.setAttribute("name", "provider-kubeconfig");
  providerKubecfg.setAttribute("rows", "20");
  providerKubecfg.setAttribute("cols", "50");
  formBody.appendChild(providerKubecfg);

  var brk5 = document.createElement("br");
  formBody.appendChild(brk5);

  var submit = document.createElement("button");
  submit.innerHTML = "Submit";
  formBody.appendChild(submit);

}

function get_org(org_name) {
  //alert(org_name);
  elementsToHide = ["input-form-service","input-form-organization", "create-status"];
  hideElements(elementsToHide);

  //deleteElement("orgtabs");
  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  url = "/organization/" + org_name;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // make a synchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        kubeconfig = fieldData['kubeconfig'];
        availableServices = fieldData['availableServices'];
        addedServices = fieldData['addedServices'];

        document.getElementById("entity-details").style.display = "none";
        //document.getElementById("entity-details").innerHTML = kubeconfig;

        deleteElement("form-details");
        deleteElement("orgtabs");
        deleteElement("orgNameLabel");
        elementsToDelete = ["brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10"];
        deleteElements(elementsToDelete);
        //deleteElement("entity-details");

        entityFormContainer = document.getElementById("entity-form-container");

        orgNameLabel = document.createElement("label");
        orgNameLabel.innerHTML = "Organization: " + org_name;
        orgNameLabel.setAttribute("for","org-name");
        orgNameLabel.setAttribute("class", "labelfont");
        orgNameLabel.setAttribute("id", "orgNameLabel");
        entityFormContainer.appendChild(orgNameLabel);

        //Create tabs
        tablist = document.createElement("ul");
        tablist.setAttribute("id", "orgtabs");
        tablist.setAttribute("class", "nav nav-pills");
        itemForm = document.createElement("li");
        itemForm.setAttribute("class", "active");
        itemFormAnchor = document.createElement("a");
        itemFormAnchor.setAttribute("data-toggle", "tab");
        itemFormAnchor.setAttribute("href", "#home");
        itemFormAnchor.setAttribute("style","text-decoration:underline;")
        itemFormAnchor.innerHTML = "Service Management";
        itemForm.appendChild(itemFormAnchor);

        itemShell = document.createElement("li");
        itemShellAnchor = document.createElement("a");
        itemShellAnchor.setAttribute("data-toggle", "tab");
        itemShellAnchor.setAttribute("href", "#shell");
        itemShellAnchor.setAttribute("style","text-decoration:underline;")
        itemShellAnchor.innerHTML = "Troubleshoot";
        itemShell.appendChild(itemShellAnchor);
        tablist.appendChild(itemForm);
        tablist.appendChild(itemShell);

        var brk1 = document.createElement("br");
        brk1.setAttribute("id","brk1");
        entityFormContainer.appendChild(brk1);

        entityFormContainer.appendChild(tablist);

        //tab contents
        tabContent = document.createElement("div");
        tabContent.setAttribute("class", "tab-content");
        entityFormContainer.appendChild(tabContent); //tabbed sections




        // Add service to organization form - tab
        addServiceDiv = document.createElement("div");
        addServiceDiv.setAttribute("id", "home");
        addServiceDiv.setAttribute("class", "tab-pane fade in active");
        tabContent.appendChild(addServiceDiv);

        var entityForm = document.createElement("div");
        entityForm.setAttribute("class", "form-popup");
        entityForm.setAttribute("id", "input-form-entity");
        entityForm.setAttribute("style", "display:block;");
        //entityFormContainer.appendChild(entityForm);
        addServiceDiv.appendChild(entityForm); // Adding entity form to the tab

        var formBody = document.createElement("form");
        formBody.setAttribute("class", "form-container");
        formBody.setAttribute("action", "add_service_to_organization");
        formBody.setAttribute("method", "post");
        formBody.setAttribute("id", "form-details");
        entityForm.appendChild(formBody);

        var brk2 = document.createElement("br");
        brk2.setAttribute("id","brk2");
        formBody.appendChild(brk2);

        addedServiceLabel = document.createElement("label");
        addedServiceLabel.innerHTML = "Services added";
        addedServiceLabel.setAttribute("for","added-services");
        addedServiceLabel.setAttribute("class", "labelfont");
        formBody.appendChild(addedServiceLabel);

        var brk3 = document.createElement("br");
        brk3.setAttribute("id","brk3");
        formBody.appendChild(brk3);

        addedServicesList = document.createElement("ul");
        for (i=0; i<addedServices.length; i++) {
            item = document.createElement("li");
            value = addedServices[i]
            console.log(value);
            item.innerHTML = value;
            addedServicesList.appendChild(item);
        }
        formBody.appendChild(addedServicesList);

        var brk4 = document.createElement("br");
        brk4.setAttribute("id","brk4");
        formBody.appendChild(brk4);


        var orgField = document.createElement("input");
        orgField.setAttribute("type", "hidden");
        orgField.setAttribute("name", "org");
        orgField.setAttribute("value", org_name);
        formBody.appendChild(orgField);


        // Shell - tab
        shellDiv = document.createElement("div");
        shellDiv.setAttribute("id", "shell");
        shellDiv.setAttribute("class", "tab-pane fade");
        tabContent.appendChild(shellDiv);

        var brk7 = document.createElement("br");
        brk7.setAttribute("id","brk7");
        shellDiv.appendChild(brk7);

        cmdLabel = document.createElement("label");
        cmdLabel.innerHTML = "kubectl command";
        cmdLabel.setAttribute("for","kubectl-cmd");
        cmdLabel.setAttribute("class","labelfont");
        shellDiv.appendChild(cmdLabel);

        var brk8 = document.createElement("br");
        brk8.setAttribute("id","brk8");
        shellDiv.appendChild(brk8);

        var cmdInput = document.createElement("input");
        cmdInput.setAttribute("type", "text");
        cmdInput.setAttribute("size","50");
        cmdInput.setAttribute("id", "cmdName");
        cmdInput.setAttribute("name", "cmdName");
        cmdInput.setAttribute("class", "labelfont");
        shellDiv.appendChild(cmdInput);

        var brk9 = document.createElement("br");
        brk9.setAttribute("id","brk9");
        shellDiv.appendChild(brk9);

        var cmdButton = document.createElement("button");
        cmdButton.innerHTML = "Enter";
        cmdButton.setAttribute("onclick","shell_handler('" + org_name + "')");
        shellDiv.appendChild(cmdButton);

        var brk10 = document.createElement("br");
        brk10.setAttribute("id","brk10");
        shellDiv.appendChild(brk10);

        var shellOp = document.createElement("div");
        shellOp.setAttribute("id","shellOp");
        shellOp.setAttribute("style","display:none;");

        shellDiv.appendChild(shellOp);
    }
  };
  xhr.send();
}

function shell_handler(org_name) {
  //alert("Collecting shell output for:" + org_name)

  cmd = document.getElementById("cmdName").value;
  console.log(cmd);

  queryParam = "org=" + org_name + '&cmd=' + cmd;
  console.log(queryParam);
  url = "/organization/command?" + queryParam;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // make a synchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        output = fieldData['output'];
        console.log(output);
        output = output.replace(/\n/g, "<br />");
        var shellOp = document.getElementById('shellOp');
        shellOp.innerHTML = output;
        shellOp.setAttribute("style","display:block;");


      }
    };
  xhr.send();
}

function create_form(entity) {
  if (entity == "service") {
    create_form_service();
  }
  if (entity == "organization") {
    create_form_organization();
  }
}


function deleteElements(fields) {
  for (const val of fields) {
    deleteElement(val);
  }
}

function deleteElement(elemId) {
  //document.getElementById("form-details") != null 
  var formBodyPrevious = document.getElementById(elemId);
  if (formBodyPrevious != null) {
    formBodyPrevious.parentNode.removeChild(formBodyPrevious);
  }
}


function create_form_service() {

  // Will not be using this static form going forward;
  document.getElementById("input-form-service").style.display = "none";

  // Hide the info panel
  document.getElementById("entity-details").style.display = "none";

  entityFormContainer = document.getElementById("entity-form-container");
  var entityForm = document.createElement("div");
  entityForm.setAttribute("class", "form-popup");
  entityForm.setAttribute("id", "input-form-entity");
  entityForm.setAttribute("style", "display:block;");
  entityFormContainer.appendChild(entityForm);

  deleteElement("form-details");

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);


  var formBody = document.createElement("form");
  formBody.setAttribute("class", "form-container");
  formBody.setAttribute("action", "register_service");
  formBody.setAttribute("method", "post");
  formBody.setAttribute("id", "form-details");
  entityForm.appendChild(formBody);

  var brk1 = document.createElement("br");
  formBody.appendChild(brk1);

  var serviceNameLabel = document.createElement("label");
  serviceNameLabel.innerHTML = "Service name";
  serviceNameLabel.setAttribute("for","serviceName");
  serviceNameLabel.setAttribute("class","labelfont");
  formBody.appendChild(serviceNameLabel);

  var brk2 = document.createElement("br");
  formBody.appendChild(brk2);

  var serviceNameInput = document.createElement("input");
  serviceNameInput.setAttribute("type", "text");
  serviceNameInput.setAttribute("id", "serviceName");
  serviceNameInput.setAttribute("name", "serviceName");
  serviceNameInput.setAttribute("class", "labelfont");
  formBody.appendChild(serviceNameInput);

  var brk3 = document.createElement("br");
  formBody.appendChild(brk3);

  var resCompositionLabel = document.createElement("label");
  resCompositionLabel.innerHTML = "Resource Composition";
  resCompositionLabel.setAttribute("for","service-res-composition");
  resCompositionLabel.setAttribute("class","labelfont");
  formBody.appendChild(resCompositionLabel);

  var brk4 = document.createElement("br");
  formBody.appendChild(brk4);

  var resComposition = document.createElement("textarea");
  resComposition.setAttribute("id", "service-res-composition");
  resComposition.setAttribute("name", "service-res-composition");
  resComposition.setAttribute("rows", "20");
  resComposition.setAttribute("cols", "50");
  formBody.appendChild(resComposition);

  var brk5 = document.createElement("br");
  formBody.appendChild(brk5);

  var submit = document.createElement("button");
  submit.innerHTML = "Submit";
  formBody.appendChild(submit);

}

function get_service(service_name) {

  elementsToHide = ["input-form-service","input-form-organization", "create-status"];
  hideElements(elementsToHide);

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  deleteElement("form-details");

  url = "/service/" + service_name;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        name = fieldData['name'];
        details = fieldData['details']

        //deleteElement("entity-details");

        //document.getElementById("entity-details").style.display = "block";
        entityDetails = document.getElementById("entity-details");
        entityDetails.innerHTML = "";
        entityDetails.setAttribute("style","display:block;")

        /*
        var label = document.createElement("label");
        label.innerHTML = "Prometheus url";
        label.setAttribute("for","prometheus-url");
        label.setAttribute("class","labelfont");
        entityDetails.appendChild(label);

        var brk1 = document.createElement("br");
        entityDetails.appendChild(brk1);*/

        prometheusFrame = document.createElement("iframe");
        prometheusFrame.setAttribute("height","100%");
        prometheusFrame.setAttribute("width","100%");
        prometheusFrame.setAttribute("name", "promFrame");
        prometheusFrame.setAttribute("src",details);
        entityDetails.appendChild(prometheusFrame);

        /*
        var aElem = document.createElement("a");
        aElem.setAttribute("href", details);
        aElem.setAttribute("target","promFrame");
        aElem.innerHTML = details;
        entityDetails.appendChild(aElem);*/

        //document.getElementById("entity-details").innerHTML = details;
    }
  };
  xhr.send();
}

function logout() {
      var xhttp;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          //Reference: https://stackoverflow.com/questions/33914245/how-to-replace-the-entire-html-webpage-with-ajax-response
            $("html").html(xhttp.responseText);
    //        render_resources(this, resource);
        }
      };
      //url = "/getAll?resource=" + resource;
      url = "/logout"
      xhttp.open("GET", url, true);
      xhttp.send();
}

function create_resource(resource) {

  document.getElementById("input-form").style.display = "block";

  elementsToHide = ["metrics-details","man-page","consumption_string_id","num_of_instances","create-status"];
  hideElements(elementsToHide);

  var fields
  url = "/service/" + resource + "/field_names";
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData)
        fields = data1["fields"]

        formDetailsElement = document.getElementById("form-details");
        header = document.createElement("h4");
        header.innerHTML = "Enter data";
        formDetailsElement.appendChild(header);

        var ul = document.createElement("ul");
        ul.setAttribute("list-style","none");
        ul.setAttribute("padding-left",0);
        formDetailsElement.appendChild(ul);

        for (const val of fields) {
            var br = document.createElement("br");
            var div = document.createElement("div");

            var label = document.createElement("label");
            label.setAttribute("for",val);
            var labelName = document.createElement("b");
            labelName.innerHTML = val;
            label.appendChild(labelName);
            formDetailsElement.appendChild(label);

            formDetailsElement.appendChild(div);

            var input = document.createElement("input");
            input.setAttribute("type", "text");
            input.setAttribute("name",val);
            formDetailsElement.appendChild(input);
            formDetailsElement.appendChild(br);
      }

      var submit = document.createElement("button");
      submit.innerHTML = "Submit";
      //submit.setAttribute("onclick","formHandler()");
      formDetailsElement.appendChild(submit);
    }
  };
  xhr.send();
}

// Not used
function formHandler() {
  form = document.getElementById("form-details");
  url = form.getAttribute('action');

  currentURL = window.location.href;

  var data = new FormData(form);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', url, true);
  xhr.onreadystatechange = function() {
    //window.location.href = currentURL;
    console.log(this.responseText);
    //alert(this.responseText);
    /*var create_status = document.getElementById("create-status");
    create_status.setAttribute("style","display:block;")
    create_status.innerHTML = this.responseText*/
  };
  xhr.onerror = function() {
    //window.location.href = currentURL;
    console.log(this.responseText);
    //alert(this.responseText);
    //var create_status = document.getElementById("create-status");
    //create_status.setAttribute("style","display:block;")
    //create_status.innerHTML = this.responseText
  }
  xhr.send(data);
}

function hideElements(fields) {
  for (const val of fields) {
    document.getElementById(val).style.display = "none";
  }
}