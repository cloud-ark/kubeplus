// Organizations to monitor -- Not used
const orgs_to_monitor = [];

function validateData() {
  return true;
}

function get_all_resources(resource){
  //alert("Hello World");
  displayString = "1. abc-org-tenant1 <br> 2. abc-org-tenant2"

  num_of_instances = document.getElementById("num_of_instances");
  num_of_instances.innerHTML = "Calculating...";
  num_of_instances.setAttribute("style", "display:block;");

  cpu = "-";
  memory = "-";
  storage = "-";
  nw_ingress = "-";
  nw_egress = "-";
  set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //Reference: https://stackoverflow.com/questions/33914245/how-to-replace-the-entire-html-webpage-with-ajax-response
        $("html").html(xhttp.responseText);
//        render_resources(this, resource);
    }
  };
  //url = "/getAll?resource=" + resource;
  url = "/service/" + resource
  xhttp.open("GET", url, true);
  xhttp.send();
}

function render_resources(xmlhttp, resource)
{
  data = xmlhttp.responseText;
  console.log(data);
  console.log("-------");
  data1 = JSON.parse(data)
  instances = data1[resource];
  console.log(instances)
  displayString = "";
  count = 1
  for (const val of instances) {
    displayString = displayString + count + ".&nbsp;&nbsp;" + val['name'] + "&nbsp;&nbsp;" + val['namespace'] + "<br>"
    count = count + 1
  }
  element = document.getElementById("service_information_space");
  element.innerHTML = displayString;
}

function get_resource_api_doc(resource){
  displayString = "Here is information about: " + resource
  //alert(displayString);
  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        render_resource_api_doc(this, resource);
    }
  };
  url = "/get_resource_manpage?resource=" + resource;
  xhttp.open("GET", url, true);
  xhttp.send();
}

function render_resource_api_doc(xmlhttp, resource)
{
  data = xmlhttp.responseText;
  console.log(data);
  console.log("-------");
  data1 = JSON.parse(data)
  manPage = data1[resource];
  console.log(manPage)

  //document.getElementById("input-form").style.display = "none";
  //document.getElementById("metrics-details").style.display = "none";

  elementsToHide = ["input-form", "metrics-details","consumption_string_id", "num_of_instances","create-status"];
  hideElements(elementsToHide);

  element = document.getElementById("man-page");
  element.innerHTML = manPage;
  document.getElementById("man-page").style.display = "block";
}

function get_resource(res_string) {

  elementsToHide = ["input-form", "man-page","create-status"];
  hideElements(elementsToHide);

  document.getElementById("metrics-details").style.display = "block";
  document.getElementById("metrics-details").setAttribute("class","table table-condensed table-striped table-bordered");
  document.getElementById("metrics-details").setAttribute("width","100%");

  cpu = "-";
  memory = "-";
  storage = "-";
  nw_ingress = "-";
  nw_egress = "-";
  set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

  num_of_instances = document.getElementById("num_of_instances");
  num_of_instances.innerHTML = "Calculating...";
  num_of_instances.setAttribute("style", "display:block;");

  myArr = res_string.split(",")

  console.log("Name:" + myArr[0]);
  instance = myArr[0];
  namespace = myArr[1];
  resource = myArr[2];
  element = document.getElementById("consumption_string_id");
  element.innerHTML = "Consumption metrics for " + instance;
  element.style.display = "block";

  // TODO: Make Ajax call to get metrics for <instance, namespace, resource>

  url = "/service/instance_data?resource=" + resource + "&instance=" + instance + "&namespace=" + namespace;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData)

        cpu = data1['cpu'];
        memory = data1['memory'];
        storage = data1['storage'];
        nw_ingress = data1['nw_ingress'];
        nw_egress = data1['nw_egress'];
        set_metrics(cpu, memory, storage, nw_ingress, nw_egress);

        app_url = data1['app_url']
        console.log("App URL:" + app_url)
        /*
        // Connections O/P is not relevant for Consumer so no need to display it.
        connections_op = data1['connections_op'];
        document.getElementById("connections_op").innerHTML = connections_op;
        document.getElementById("connections_op").style.display = "block";
        */

        app_url1 = "<hr><a href=\"" + app_url + "\">Application URL</a><hr>"
        document.getElementById("app_url").innerHTML = app_url1;
        document.getElementById("app_url").style.display = "block";

        log_data = data1['logs'];
        console.log(log_data)

        textarea = "<label style=\"font-size:large;\">Application Logs</label><br><p><textarea style=\"overflow:scroll;width:600px;height:200px\">" + log_data + "</p></textarea>";
        document.getElementById("app_logs_data").innerHTML = textarea;
        document.getElementById("app_logs_data").style.display = "block";

        /*
        logs_url = "<a href=\"" + "\">Application Logs</a><hr><br></br>"
        document.getElementById("app_logs_url").innerHTML = logs_url;
        document.getElementById("app_logs_url").style.display = "block";
        document.getElementById("app_logs_url").onclick = get_logs(resource, instance, namespace)
        */

        elementsToHide = ["num_of_instances"];
        hideElements(elementsToHide);
      }
    };
  xhr.send();
}

function get_logs(resource, instance, namespace) {

  url = "/service/instance_logs?resource=" + resource + "&instance=" + instance + "&namespace=" + namespace;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData);
        log_data = data1['logs'];
        console.log(log_data)

        textarea = "<textarea style=\"overflow:scroll;width:300px;height:200px\">" + log_data + "</textarea>";
        document.getElementById("app_logs_data").innerHTML = textarea;
        document.getElementById("app_logs_data").style.display = "block";
      }
    };
  xhr.send();
}

function set_metrics(cpu, memory, storage, ingress, egress) {
  cpuelement = document.getElementById("total_cpu");
  cpuelement.innerHTML = cpu + "<br> (millicores)";

  memelement = document.getElementById("total_memory");
  memelement.innerHTML = memory + "<br> (mebibytes)" ;

  storageelement = document.getElementById("total_storage");
  storageelement.innerHTML = storage + "<br> (Giga bytes)" ;

  ingresselement = document.getElementById("total_nw_ingress");
  ingresselement.innerHTML = nw_ingress + "<br> (bytes)" ;

  egresselement = document.getElementById("total_nw_egress");
  egresselement.innerHTML = nw_egress + "<br> (bytes)" ;
}

function create_form_organization() {

  // Will not be using this static form going forward;
  document.getElementById("input-form-organization").style.display = "none";

  // Hide the info panel
  document.getElementById("entity-details").style.display = "none";

  elementsToHide = ["create-status"];
  hideElements(elementsToHide);

  entityFormContainer = document.getElementById("entity-form-container");
  var entityForm = document.createElement("div");
  entityForm.setAttribute("class", "form-popup");
  entityForm.setAttribute("id", "input-form-entity");
  entityForm.setAttribute("style", "display:block;");
  entityFormContainer.appendChild(entityForm);

  deleteElement("form-details");

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["show_steps","brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  var formBody = document.createElement("form");
  formBody.setAttribute("class", "form-container");
  formBody.setAttribute("action", "register_organization");
  formBody.setAttribute("method", "post");
  formBody.setAttribute("id", "form-details");
  entityForm.appendChild(formBody);

  var brk1 = document.createElement("br");
  formBody.appendChild(brk1);

  var orgNameLabel = document.createElement("label");
  orgNameLabel.innerHTML = "Cluster name";
  orgNameLabel.setAttribute("for","orgName");
  orgNameLabel.setAttribute("class", "labelfont");
  formBody.appendChild(orgNameLabel);

  var brk2 = document.createElement("br");
  formBody.appendChild(brk2);

  var orgNameInput = document.createElement("input");
  orgNameInput.setAttribute("type", "text");
  orgNameInput.setAttribute("id", "orgName");
  orgNameInput.setAttribute("name", "orgName");
  formBody.appendChild(orgNameInput);

  var brk3 = document.createElement("br");
  formBody.appendChild(brk3);

  var providerKubeconfigLabel = document.createElement("label");
  providerKubeconfigLabel.innerHTML = "Provider Kubeconfig";
  providerKubeconfigLabel.setAttribute("for","provider-kubeconfig");
  providerKubeconfigLabel.setAttribute("class", "labelfont");
  formBody.appendChild(providerKubeconfigLabel);

  var brk4 = document.createElement("br");
  formBody.appendChild(brk4);

  var providerKubecfg = document.createElement("textarea");
  providerKubecfg.setAttribute("id", "provider-kubeconfig");
  providerKubecfg.setAttribute("name", "provider-kubeconfig");
  providerKubecfg.setAttribute("rows", "20");
  providerKubecfg.setAttribute("cols", "50");
  formBody.appendChild(providerKubecfg);

  var brk5 = document.createElement("br");
  formBody.appendChild(brk5);

  var submit = document.createElement("button");
  submit.innerHTML = "Submit";
  formBody.appendChild(submit);

}

function get_resource_topology(org, service, instance, namespace) {
 
  topologydiv = document.getElementById("topology");
  spinner = document.createElement("div");
  spinner.setAttribute("class","loader");
  spinner.setAttribute("id","spinner")
  topologydiv.appendChild(spinner);

  queryString = "org=" + org +  "&service=" + service + "&instance=" + instance + "&namespace=" + namespace;
  console.log("Query string:" + queryString) 
  url = "/resource_details?" + queryString
  console.log("URL" + url)
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true); // make an asynchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        deleteElement("spinner");

        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");

        topologyData = fieldData['topology'];
        topology = document.getElementById("app-topology");

        topologyLabel = document.createElement("label");
        topologyLabel.innerHTML = "Application Topology";
        topologyLabel.setAttribute("for","application-topology");
        topologyLabel.setAttribute("class", "labelfont");
        topologyLabel.setAttribute("style", "padding-left: 10px;");

        topology.appendChild(topologyLabel);
        topologyFrame = document.createElement("iframe");
        topologyFrame.setAttribute("height","100%");
        topologyFrame.setAttribute("width","100%");
        topologyFrame.setAttribute("scrolling","yes");
        topologyFrame.setAttribute("name", "topologyFrame");
        topologyFrame.setAttribute("srcdoc",topologyData);
        topology.appendChild(topologyFrame);

        app_url = fieldData['app_url'];
        console.log("App URL:" + app_url);

        app_url1 = "<hr><a class=\"labelfont\" target=\"_blank\" rel=\"noopener noreferrer\" href=\"" + app_url + "\">Application URL</a><hr>"
        document.getElementById("app-url").innerHTML = app_url1;
        document.getElementById("app-url").setAttribute("style","display: block; padding-left:10px;");

        log_data = fieldData['logs'];
        console.log(log_data)

        textarea = "<label class=\"labelfont\">Application Logs</label><br><p><textarea style=\"overflow:scroll;width:480px;height:200px\">" + log_data + "</p></textarea>";
        document.getElementById("app-logs").innerHTML = textarea;
        document.getElementById("app-logs").setAttribute("style","display: block; padding-left:10px;");

      }
    };
  xhr.send();
}

function show_steps_help() {

  document.getElementById("entity-details").style.display = "none";

  deleteElement("form-details");
  deleteElement("orgtabs");
  deleteElement("orgNameLabel");
  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["show_steps","div-to-create-instance","available-services","brk1","brk2","brk2a","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10"];
  deleteElements(elementsToDelete);

  entity_form_container = document.getElementById("entity-form-container");

  show_steps_div = document.createElement("div");
  show_steps_div.setAttribute("id","show_steps");

  ul = document.createElement("ul");
  show_steps_div.appendChild(ul);

  how_to_use_label = document.createElement("label");
  how_to_use_label.innerHTML = "How to use?";
  how_to_use_label.setAttribute("class","labelfont");
  how_to_use_label.setAttribute("style","text-align:center;");
  show_steps_div.appendChild(how_to_use_label);

  step1 = document.createElement("li");
  step1.innerHTML = "Step 1: Create Service using Application Helm chart."
  show_steps_div.appendChild(step1);
  step1_img = document.createElement("img");
  step1_img.setAttribute("src","static/images/create-service.png");
  step1_img.setAttribute("style","width: 400px; height: 200px;");
  show_steps_div.appendChild(step1_img);
  show_steps_div.appendChild(document.createElement("p"));

  step2 = document.createElement("li");
  step2.innerHTML = "Step 2: Register cluster using Provider kubeconfig."
  show_steps_div.appendChild(step2);
  step2_img = document.createElement("img");
  step2_img.setAttribute("src","static/images/register-cluster.png");
  step2_img.setAttribute("style","width: 400px; height: 300px;");
  show_steps_div.appendChild(step2_img);
  show_steps_div.appendChild(document.createElement("p"));

  step3 = document.createElement("li");
  step3.innerHTML = "Step 3: Add Service to the registered cluster from the cluster link."
  show_steps_div.appendChild(step3);
  step3_img = document.createElement("img");
  step3_img.setAttribute("src","static/images/add-manage-service.png");
  step3_img.setAttribute("style","width: 400px; height: 150px;");
  show_steps_div.appendChild(step3_img);
  show_steps_div.appendChild(document.createElement("p"));

  step4 = document.createElement("li");
  step4.innerHTML = "Step 4: Create Service instance on the cluster from the cluster link."
  show_steps_div.appendChild(step4);
  step4_img = document.createElement("img");
  step4_img.setAttribute("src","static/images/create-instance.png");
  step4_img.setAttribute("style","width: 400px; height: 150px;");
  show_steps_div.appendChild(step4_img);
  show_steps_div.appendChild(document.createElement("p"));

  step5 = document.createElement("li");
  step5.innerHTML = "Step 5: Monitor Service instance from the Service link."
  show_steps_div.appendChild(step5);
  step5_img = document.createElement("img");
  step5_img.setAttribute("src","static/images/monitor-service.png");
  step5_img.setAttribute("style","width: 650px; height: 200px;");
  show_steps_div.appendChild(step5_img);
  show_steps_div.appendChild(document.createElement("p"));

  step6 = document.createElement("li");
  step6.innerHTML = "Step 6: Troubleshoot Service instance from the cluster link."
  show_steps_div.appendChild(step6);
  step6_img = document.createElement("img");
  step6_img.setAttribute("src","static/images/access-cluster.png");
  step6_img.setAttribute("style","width: 500px; height: 200px;");
  show_steps_div.appendChild(step6_img);
  show_steps_div.appendChild(document.createElement("p"));

  entity_form_container.appendChild(show_steps_div);

}

function render_organization(fieldData, org_name) {

        kubeconfig = fieldData['kubeconfig'];
        availableServices = fieldData['availableServices'];
        addedServices = fieldData['addedServices'];
        serviceInstances = fieldData['serviceInstances'];

        document.getElementById("entity-details").style.display = "none";
        //document.getElementById("entity-details").innerHTML = kubeconfig;

        deleteElement("form-details");
        deleteElement("orgtabs");
        deleteElement("orgNameLabel");
        elementsToDelete = ["show_steps","brk1","brk2","brk2a","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10"];
        deleteElements(elementsToDelete);
        //deleteElement("entity-details");

        entityFormContainer = document.getElementById("entity-form-container");

        orgNameLabel = document.createElement("label");
        orgNameLabel.innerHTML = "Cluster: " + org_name;
        orgNameLabel.setAttribute("for","org-name");
        orgNameLabel.setAttribute("class", "labelfont");
        orgNameLabel.setAttribute("id", "orgNameLabel");
        entityFormContainer.appendChild(orgNameLabel);

        //Create tabs
        tablist = document.createElement("ul");
        tablist.setAttribute("id", "orgtabs");
        tablist.setAttribute("class", "nav nav-pills");
        itemForm = document.createElement("li");
        itemForm.setAttribute("class", "active");
        itemFormAnchor = document.createElement("a");
        itemFormAnchor.setAttribute("data-toggle", "tab");
        itemFormAnchor.setAttribute("href", "#home");
        itemFormAnchor.setAttribute("style","text-decoration:underline;")
        itemFormAnchor.innerHTML = "Add and Manage Service";
        itemForm.appendChild(itemFormAnchor);

        itemShell = document.createElement("li");
        itemShellAnchor = document.createElement("a");
        itemShellAnchor.setAttribute("data-toggle", "tab");
        itemShellAnchor.setAttribute("href", "#shell");
        itemShellAnchor.setAttribute("style","text-decoration:underline;")
        itemShellAnchor.innerHTML = "Access cluster";
        itemShell.appendChild(itemShellAnchor);
        tablist.appendChild(itemForm);
        tablist.appendChild(itemShell);

        var brk1 = document.createElement("br");
        brk1.setAttribute("id","brk1");
        entityFormContainer.appendChild(brk1);

        entityFormContainer.appendChild(tablist);

        //tab contents
        tabContent = document.createElement("div");
        tabContent.setAttribute("class", "tab-content");
        entityFormContainer.appendChild(tabContent); //tabbed sections

        // Add service to organization form - tab
        addServiceDiv = document.createElement("div");
        addServiceDiv.setAttribute("id", "home");
        addServiceDiv.setAttribute("class", "tab-pane fade in active");
        tabContent.appendChild(addServiceDiv);

        var entityForm = document.createElement("div");
        entityForm.setAttribute("class", "form-popup");
        entityForm.setAttribute("id", "input-form-entity");
        entityForm.setAttribute("style", "display:block;");
        //entityFormContainer.appendChild(entityForm);
        addServiceDiv.appendChild(entityForm); // Adding entity form to the tab

        var formBody = document.createElement("form");
        formBody.setAttribute("class", "form-container");
        formBody.setAttribute("action", "add_service_to_organization");
        formBody.setAttribute("method", "post");
        formBody.setAttribute("id", "form-details");
        entityForm.appendChild(formBody);

        var brk4 = document.createElement("br");
        brk4.setAttribute("id","brk4");
        formBody.appendChild(brk4);


        availableServiceLabel = document.createElement("label");
        availableServiceLabel.innerHTML = "Select service to add";
        availableServiceLabel.setAttribute("for","available-services");
        availableServiceLabel.setAttribute("class", "labelfont");
        formBody.appendChild(availableServiceLabel);

        var brk5 = document.createElement("br");
        brk5.setAttribute("id","brk5");
        formBody.appendChild(brk5);

        availableServicesdropdown = document.createElement("select");
        availableServicesdropdown.setAttribute("name","available-services");
        availableServicesdropdown.setAttribute("id", "available-services");
        for (i=0; i<availableServices.length; i++) {
            option = document.createElement("option");
            value = availableServices[i]
            console.log(value);
            option.setAttribute("value", value);
            option.innerHTML = value;
            availableServicesdropdown.appendChild(option);
        }
        formBody.appendChild(availableServicesdropdown);

        var brk6 = document.createElement("br");
        brk6.setAttribute("id","brk6");
        formBody.appendChild(brk6);

        var submit = document.createElement("button");
        submit.innerHTML = "Add service";
        //One idea to detect newly created service instances was to issue
        //Ajax calls for triggering organization level monitoring.
        //But this below call was included as part of Add Service POST handler,
        //which after handling on the server-side resulted in the Ajax loosing
        //context of the orgs_to_monitor list. Ultimately it was decided to
        //perform the org monitoring on the server-side through a separate Python
        //Process. Hence commenting below out. Leaving this here for future reference.
        //submit.setAttribute("onclick","setup_monitor('" + org_name + "')");
        formBody.appendChild(submit);

        var orgField = document.createElement("input");
        orgField.setAttribute("type", "hidden");
        orgField.setAttribute("name", "org");
        orgField.setAttribute("value", org_name);
        formBody.appendChild(orgField);


        var brk2 = document.createElement("br");
        brk2.setAttribute("id","brk2");
        formBody.appendChild(brk2);

        var brk2a = document.createElement("br");
        brk2a.setAttribute("id","brk2a");
        formBody.appendChild(brk2a);

        /*
        var formToCreateInstance = document.createElement("form");
        formToCreateInstance.setAttribute("class", "form-container");
        formToCreateInstance.setAttribute("action", "create_instance");
        formToCreateInstance.setAttribute("method", "post");
        formToCreateInstance.setAttribute("id", "form-to-create-instance");
        entityForm.appendChild(formToCreateInstance);*/

        var divToCreateInstance = document.createElement("div");
        divToCreateInstance.setAttribute("id", "div-to-create-instance");
        entityForm.appendChild(divToCreateInstance);

        addedServiceLabel = document.createElement("label");
        addedServiceLabel.innerHTML = "Services added to the cluster " + org_name;
        addedServiceLabel.setAttribute("for","added-services");
        addedServiceLabel.setAttribute("class", "labelfont");
        divToCreateInstance.appendChild(addedServiceLabel);

        var brk3 = document.createElement("br");
        brk3.setAttribute("id","brk3");
        divToCreateInstance.appendChild(brk3);

        addedServicesList = document.createElement("ul");
        divToCreateInstance.appendChild(addedServicesList);
        for (i=0; i<addedServices.length; i++) {
            item = document.createElement("li");
            value = addedServices[i];
            item.setAttribute("id",value);
            console.log(value);
            item.innerHTML = value + "&nbsp;&nbsp;";
            addedServicesList.appendChild(item);

            serviceInstanceList = serviceInstances[value];

            var createInstanceAnchor = document.createElement("a");
            createInstanceAnchor.innerHTML = "Create Instance";
            //createInstanceAnchor.setAttribute("style","float: right");
            createInstanceAnchor.setAttribute("data-toggle","modal");
            createInstanceAnchor.setAttribute("href","#createInstanceModal");
            createInstanceAnchor.setAttribute("onclick","create_instance_handler('" + value + "," + org_name + "')");
            item.appendChild(createInstanceAnchor);

            item.appendChild(document.createElement("br"));
            createdInstancesLabel = document.createElement("label");
            createdInstancesLabel.innerHTML = "Created Instances:";
            createdInstancesLabel.setAttribute("for","created-instances");
            createdInstancesLabel.setAttribute("class", "labelfont");
            item.appendChild(createdInstancesLabel);

            serviceInstanceUL = document.createElement("ul");
            for (j=0;j<serviceInstanceList.length; j++) {
              item1 = document.createElement("li");
              value1 = serviceInstanceList[j];
              parts = value.split(".")
              kind = parts[0];
              instance = value1['NAME'];
              // No need to prepend Namespace
              ns = value1['NAMESPACE'];
              //toprint = ns + ' ' + instance
              toprint = instance + "&nbsp;&nbsp;&nbsp;";
              console.log(toprint);
              topology = document.createElement("a");
              topology.setAttribute("id","topology");
              //topology.setAttribute("href","#");

              topology.setAttribute("data-toggle","modal");
              topology.setAttribute("href","#instanceDetailsModal");

              topologyhandler = `get_resource_topology('${org_name}','${kind}','${instance}','${ns}')`;
              console.log(topologyhandler);
              topology.setAttribute("onclick",topologyhandler);
              topology.innerHTML = toprint;
              serviceInstanceUL.appendChild(item1);
              item1.appendChild(topology);

              var deleteInstanceAnchor = document.createElement("a");
              deleteInstanceAnchor.innerHTML = "Delete Instance";
              deleteInstanceAnchor.setAttribute("href","#");
              deleteInstanceHandler = `delete_instance('${org_name}','${kind}','${instance}','${ns}')`;
              deleteInstanceAnchor.setAttribute("onclick",deleteInstanceHandler);
              item1.appendChild(deleteInstanceAnchor);

            }
            item.appendChild(serviceInstanceUL);
        }

        // Shell - tab
        shellDiv = document.createElement("div");
        shellDiv.setAttribute("id", "shell");
        shellDiv.setAttribute("class", "tab-pane fade");
        tabContent.appendChild(shellDiv);

        var brk7 = document.createElement("br");
        brk7.setAttribute("id","brk7");
        shellDiv.appendChild(brk7);

        cmdLabel = document.createElement("label");
        cmdLabel.innerHTML = "kubectl command";
        cmdLabel.setAttribute("for","kubectl-cmd");
        cmdLabel.setAttribute("class","labelfont");
        shellDiv.appendChild(cmdLabel);

        var brk8 = document.createElement("br");
        brk8.setAttribute("id","brk8");
        shellDiv.appendChild(brk8);

        var cmdInput = document.createElement("input");
        cmdInput.setAttribute("type", "text");
        cmdInput.setAttribute("size","50");
        cmdInput.setAttribute("id", "cmdName");
        cmdInput.setAttribute("name", "cmdName");
        cmdInput.setAttribute("class", "labelfont");
        shellDiv.appendChild(cmdInput);

        var brk9 = document.createElement("br");
        brk9.setAttribute("id","brk9");
        shellDiv.appendChild(brk9);

        var cmdButton = document.createElement("button");
        cmdButton.innerHTML = "Enter";
        cmdButton.setAttribute("onclick","shell_handler('" + org_name + "')");
        shellDiv.appendChild(cmdButton);

        var brk10 = document.createElement("br");
        brk10.setAttribute("id","brk10");
        shellDiv.appendChild(brk10);

        var shellOp = document.createElement("div");
        shellOp.setAttribute("id","shellOp");
        shellOp.setAttribute("style","display:none;");

        shellDiv.appendChild(shellOp);



}

function delete_instance(org, kind, instance, namespace) {
  alert("TODO: Delete instance");
}

function get_org(org_name) {
  //alert(org_name);
  elementsToHide = ["input-form-service","input-form-organization", "create-status"];
  hideElements(elementsToHide);

  //deleteElement("orgtabs");
  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["show_steps","brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  url = "/organization/" + org_name;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // make a synchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");

        render_organization(fieldData, org_name);

    }

  };
  xhr.send();
}

// Not used.
function setup_monitor(org_name) {
  if (org_name != "") {
    orgs_to_monitor.push(org_name);
  }
  console.log("orgs_to_monitor:");
  console.log(orgs_to_monitor);
  setInterval(monitor_org, 8000);
}

// Not used.
function monitor_org() {
  queryParam = orgs_to_monitor.join();
  url = "/organization/monitor?orgs=" + queryParam;
  console.log("Org url to monitor:" + url);
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // make a synchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        output = fieldData['output'];
        console.log(output);
        //output = output.replace(/\n/g, "<br />");
      }
    };
  xhr.send();
}

function create_instance_handler(service_fqname_and_org_name) {

  parts = service_fqname_and_org_name.split(",")
  service_fqname = parts[0].trim();

  org_name = parts[1].trim();

  console.log("Create instance for:" + service_fqname + " Org:" + org_name);

  // Query the fields and create the Modal for instance creation.
  deleteElement("modal-create-instance-form-div");
  div1 = document.createElement("div");
  div1.setAttribute("aria-hidden","true");
  div1.setAttribute("id","modal-create-instance-form-div");

  modalHeader = document.getElementById("modal-header-div");

  var label1 = document.createElement("label");
  label1.setAttribute("for",org_name);
  var label1Name = document.createElement("b");
  label1Name.setAttribute("id","modal-form-org-label");
  label1Name.innerHTML = "Org: " + org_name;
  label1.appendChild(label1Name);
  modalHeader.appendChild(label1);

  var label2 = document.createElement("label");
  label2.setAttribute("for", service_fqname);
  var label2Name = document.createElement("b");
  label2Name.setAttribute("id","modal-form-crd-label");
  label2Name.innerHTML = "Service: " + service_fqname;
  label2.appendChild(label2Name);
  modalHeader.appendChild(label2);

  createInstanceModalDiv = document.getElementById("create-instance-modal-body");
  createInstanceModalDiv.appendChild(div1);

  var xhttp;
  xhttp = new XMLHttpRequest();

  encodedServiceFQName = encodeURIComponent(service_fqname);

  queryParam = "crd=" + encodedServiceFQName;
  console.log("QueryParam:" + queryParam);
  url = "/field_names?" + queryParam;
  console.log("URL:" + url);
  xhttp.open("GET", url, true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      fieldData = JSON.parse(this.responseText);
      console.log(fieldData);
      console.log("-------");
      fields = fieldData['fields'];
      console.log(fields);

      createInstanceForm = document.getElementById("form-create-service-instance");
      crdNameHiddenField = document.createElement("input");
      crdNameHiddenField.setAttribute("type","hidden");
      crdNameHiddenField.setAttribute("id",encodedServiceFQName);
      crdNameHiddenField.setAttribute("name","crd");
      crdNameHiddenField.setAttribute("value",encodedServiceFQName);

      orgNameHiddenField = document.createElement("input");
      orgNameHiddenField.setAttribute("type","hidden");
      orgNameHiddenField.setAttribute("id",org_name);
      orgNameHiddenField.setAttribute("name","org");
      orgNameHiddenField.setAttribute("value",org_name);

      createInstanceForm.appendChild(crdNameHiddenField);
      createInstanceForm.appendChild(orgNameHiddenField);

      for (const val of fields) {

        var label = document.createElement("label");
        label.setAttribute("for",val);
        var labelName = document.createElement("b");
        labelName.innerHTML = val;
        label.appendChild(labelName);
        div1.appendChild(label);
        var br1 = document.createElement("br");
        div1.appendChild(br1);

        var input = document.createElement("input");
        input.setAttribute("type", "text");
        input.setAttribute("name",val);
        div1.appendChild(input);
        var br2 = document.createElement("br");
        div1.appendChild(br2);
      }
    }
  };
  xhttp.send();
}

function create_instance() {
  //alert("Create instance called.");

  // Submit Modal form - approach 1
  document.getElementById('form-create-service-instance').submit();

  // Submit Modal form - approach 2
 /* var xhttp;
  xhttp = new XMLHttpRequest();

  org = document.getElementById("modal-form-org-label").innerHTML;
  crd = document.getElementById("modal-form-crd-label").innerHTML;

  parts = org.split(":");
  org1 = parts[1].trim();

  parts = crd.split(":");
  crd1 = parts[1].trim();

  url = "/create_service_instance?org=" + org1 + "&crd=" + crd1
  console.log("POST url:" + url) 
  xhttp.open("POST", url, true);

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //Reference: https://stackoverflow.com/questions/33914245/how-to-replace-the-entire-html-webpage-with-ajax-response
        $("html").html(xhttp.responseText);
    }
  };
  xhttp.send();
*/
}

function shell_handler(org_name) {
  //alert("Collecting shell output for:" + org_name)

  cmd = document.getElementById("cmdName").value;
  console.log(cmd);

  queryParam = "org=" + org_name + '&cmd=' + cmd;
  console.log(queryParam);
  url = "/organization/command?" + queryParam;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // make a synchronous request to wait for data for org to come in.
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        output = fieldData['output'];
        console.log(output);
        output = output.replace(/\n/g, "<br />");
        var shellOp = document.getElementById('shellOp');
        shellOp.innerHTML = output;
        shellOp.setAttribute("style","display:block;");


      }
    };
  xhr.send();
}

function create_form(entity) {
  if (entity == "service") {
    create_form_service();
  }
  if (entity == "organization") {
    create_form_organization();
  }
}


function deleteElements(fields) {
  for (const val of fields) {
    deleteElement(val);
  }
}

function deleteElement(elemId) {
  //document.getElementById("form-details") != null 
  var formBodyPrevious = document.getElementById(elemId);
  if (formBodyPrevious != null) {
    formBodyPrevious.parentNode.removeChild(formBodyPrevious);
  }
}


function create_form_service() {

  // Will not be using this static form going forward;
  document.getElementById("input-form-service").style.display = "none";

  // Hide the info panel
  document.getElementById("entity-details").style.display = "none";

  elementsToHide = ["create-status"];
  hideElements(elementsToHide);

  entityFormContainer = document.getElementById("entity-form-container");
  var entityForm = document.createElement("div");
  entityForm.setAttribute("class", "form-popup");
  entityForm.setAttribute("id", "input-form-entity");
  entityForm.setAttribute("style", "display:block;");
  entityFormContainer.appendChild(entityForm);

  deleteElement("form-details");

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["show_steps","brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);


  var formBody = document.createElement("form");
  formBody.setAttribute("class", "form-container");
  formBody.setAttribute("action", "register_service");
  formBody.setAttribute("method", "post");
  formBody.setAttribute("id", "form-details");
  formBody.setAttribute("enctype","multipart/form-data");
  entityForm.appendChild(formBody);

  var brk1 = document.createElement("br");
  formBody.appendChild(brk1);

  var serviceNameLabel = document.createElement("label");
  serviceNameLabel.innerHTML = "Service name";
  serviceNameLabel.setAttribute("for","serviceName");
  serviceNameLabel.setAttribute("class","labelfont");
  formBody.appendChild(serviceNameLabel);

  var brk2 = document.createElement("br");
  formBody.appendChild(brk2);

  var serviceNameInput = document.createElement("input");
  serviceNameInput.setAttribute("type", "text");
  serviceNameInput.setAttribute("id", "serviceName");
  serviceNameInput.setAttribute("name", "serviceName");
  serviceNameInput.setAttribute("class", "labelfont");
  formBody.appendChild(serviceNameInput);

  var brk3 = document.createElement("br");
  formBody.appendChild(brk3);

  var hr = document.createElement("hr")
  formBody.append(hr);

  var helmChartURLLabel = document.createElement("label");
  helmChartURLLabel.innerHTML = "Helm chart url (for public charts)";
  helmChartURLLabel.setAttribute("for","helm-chart-url");
  helmChartURLLabel.setAttribute("class","labelfont");
  formBody.appendChild(helmChartURLLabel);

  var brk4 = document.createElement("br");
  formBody.appendChild(brk4);

  var helmChartURL = document.createElement("input");
  helmChartURL.setAttribute("type", "text");
  helmChartURL.setAttribute("id", "helm-chart-url");
  helmChartURL.setAttribute("name", "helm-chart-url");
  helmChartURL.setAttribute("size","50");
  //resComposition.setAttribute("rows", "20");
  //resComposition.setAttribute("cols", "50");
  formBody.appendChild(helmChartURL);

  var brk6 = document.createElement("br");
  formBody.appendChild(brk6);

  var selectorLabel = document.createElement("label");
  selectorLabel.innerHTML = "------------------- or ------------------- ";
  selectorLabel.setAttribute("for","chart-url-or-upload");
  selectorLabel.setAttribute("class","labelfont");
  formBody.appendChild(selectorLabel);


  /*
  var brk5 = document.createElement("br");
  formBody.appendChild(brk5);

  var helmChartNameLabel = document.createElement("label");
  helmChartNameLabel.innerHTML = "Helm chart name";
  helmChartNameLabel.setAttribute("for","helm-chart-name");
  helmChartNameLabel.setAttribute("class","labelfont");
  formBody.appendChild(helmChartNameLabel);

  var helmChartName = document.createElement("input");
  helmChartName.setAttribute("type", "text");
  helmChartName.setAttribute("id", "helm-chart-name");
  helmChartName.setAttribute("name", "helm-chart-name");
  helmChartName.setAttribute("size","50");
  formBody.appendChild(helmChartName);
  */

  var brk7 = document.createElement("br");
  formBody.appendChild(brk7);

  var helmChartPathLabel = document.createElement("label");
  helmChartPathLabel.innerHTML = "Helm chart Path (tgz file) (for private charts)";
  helmChartPathLabel.setAttribute("for","helm-chart-path");
  helmChartPathLabel.setAttribute("class","labelfont");
  formBody.appendChild(helmChartPathLabel);

  var brk8 = document.createElement("br");
  formBody.appendChild(brk8);

  var helmChartPath = document.createElement("input");
  helmChartPath.setAttribute("type", "file");
  helmChartPath.setAttribute("id", "helm-chart-path");
  helmChartPath.setAttribute("name", "helm-chart-path");
  formBody.appendChild(helmChartPath);

  var brk9 = document.createElement("br");
  formBody.appendChild(brk9);

  var brk10 = document.createElement("br");
  formBody.appendChild(brk10);

  var submit = document.createElement("button");
  submit.innerHTML = "Submit";
  formBody.appendChild(submit);

}

function get_service(service_name) {

  elementsToHide = ["input-form-service","input-form-organization", "create-status"];
  hideElements(elementsToHide);

  deleteElement("shell");
  deleteElement("home");
  deleteElement("orgNameLabel");
  elementsToDelete = ["show_steps","brk1","brk2","brk3","brk4","brk5","brk6","brk7","brk8","brk9","brk10","orgtabs"];
  deleteElements(elementsToDelete);

  deleteElement("form-details");

  url = "/service/" + service_name;
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = JSON.parse(this.responseText);
        console.log(fieldData);
        console.log("-------");
        name = fieldData['name'];
        details = fieldData['details'];
        details = details.replace('\r','');

        //deleteElement("entity-details");

        //document.getElementById("entity-details").style.display = "block";
        entityDetails = document.getElementById("entity-details");
        entityDetails.innerHTML = "";
        entityDetails.setAttribute("style","display:block;")

        /*
        var label = document.createElement("label");
        label.innerHTML = "Prometheus url";
        label.setAttribute("for","prometheus-url");
        label.setAttribute("class","labelfont");
        entityDetails.appendChild(label);

        var brk1 = document.createElement("br");
        entityDetails.appendChild(brk1);*/

        prometheusFrame = document.createElement("iframe");
        prometheusFrame.setAttribute("height","100%");
        prometheusFrame.setAttribute("width","100%");
        prometheusFrame.setAttribute("name", "promFrame");
        prometheusFrame.setAttribute("src",details);
        entityDetails.appendChild(prometheusFrame);

        /*
        var aElem = document.createElement("a");
        aElem.setAttribute("href", details);
        aElem.setAttribute("target","promFrame");
        aElem.innerHTML = details;
        entityDetails.appendChild(aElem);*/

        //document.getElementById("entity-details").innerHTML = details;
    }
  };
  xhr.send();
}

function logout() {
      var xhttp;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          //Reference: https://stackoverflow.com/questions/33914245/how-to-replace-the-entire-html-webpage-with-ajax-response
          $("html").html(xhttp.responseText);
        }
      };
      //url = "/getAll?resource=" + resource;
      url = "/logout"
      xhttp.open("GET", url, true);
      xhttp.send();
}

function set_new_settings() {
  //alert("Inside set_new_settings");

  webhookField = document.getElementById("webhook");
  webhook = webhookField.value;

  channelField = document.getElementById("channel");
  channel = channelField.value;

  console.log("Webhook:" + webhook + " Channel:" + channel);

      var xhttp;
      xhttp = new XMLHttpRequest();

      encodedWebhook = encodeURIComponent(webhook);
      encodedChannel = encodeURIComponent(channel);

      queryParam = "webhook=" + encodedWebhook + "&channel=" + encodedChannel;
      console.log("QueryParam:" + queryParam);
      url = "/set_new_settings?" + queryParam;
      console.log("URL:" + url);
      xhttp.open("PUT", url, true);
      xhttp.send();

      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          fieldData = JSON.parse(this.responseText);
          console.log(fieldData);
          console.log("-------");
          webhook = fieldData['webhook'];
          channel = fieldData['channel'];

          webhookField = document.getElementById("webhook");
          webhookField.setAttribute("value", webhook);

          channelField = document.getElementById("channel");
          channelField.setAttribute("value", channel);

        }
      };
}

function fetch_current_settings() {
  //alert("Configure Control center here..")

  //modalbody = document.getElementById("my-modal-body");
  //modalbody.innerHTML = "TTL";

      var xhttp;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          fieldData = JSON.parse(this.responseText);
          console.log(fieldData);
          console.log("-------");
          webhook = fieldData['webhook'];
          channel = fieldData['channel'];

          webhookField = document.getElementById("webhook");
          webhookField.setAttribute("value", webhook);

          channelField = document.getElementById("channel");
          channelField.setAttribute("value", channel);

        }
      };
      url = "/fetch_current_settings";
      xhttp.open("GET", url, true);
      xhttp.send();
}

// Not used --
function create_resource(resource) {

  document.getElementById("input-form").style.display = "block";

  elementsToHide = ["metrics-details","man-page","consumption_string_id","num_of_instances","create-status"];
  hideElements(elementsToHide);

  var fields
  url = "/service/" + resource + "/field_names";
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        fieldData = this.responseText;
        console.log(fieldData);
        console.log("-------");
        data1 = JSON.parse(fieldData)
        fields = data1["fields"]

        formDetailsElement = document.getElementById("form-details");
        header = document.createElement("h4");
        header.innerHTML = "Enter data";
        formDetailsElement.appendChild(header);

        var ul = document.createElement("ul");
        ul.setAttribute("list-style","none");
        ul.setAttribute("padding-left",0);
        formDetailsElement.appendChild(ul);

        for (const val of fields) {
            var br = document.createElement("br");
            var div = document.createElement("div");

            var label = document.createElement("label");
            label.setAttribute("for",val);
            var labelName = document.createElement("b");
            labelName.innerHTML = val;
            label.appendChild(labelName);
            formDetailsElement.appendChild(label);

            formDetailsElement.appendChild(div);

            var input = document.createElement("input");
            input.setAttribute("type", "text");
            input.setAttribute("name",val);
            formDetailsElement.appendChild(input);
            formDetailsElement.appendChild(br);
      }

      var submit = document.createElement("button");
      submit.innerHTML = "Submit";
      //submit.setAttribute("onclick","formHandler()");
      formDetailsElement.appendChild(submit);
    }
  };
  xhr.send();
}

// Not used
function formHandler() {
  form = document.getElementById("form-details");
  url = form.getAttribute('action');

  currentURL = window.location.href;

  var data = new FormData(form);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', url, true);
  xhr.onreadystatechange = function() {
    //window.location.href = currentURL;
    console.log(this.responseText);
    //alert(this.responseText);
    /*var create_status = document.getElementById("create-status");
    create_status.setAttribute("style","display:block;")
    create_status.innerHTML = this.responseText*/
  };
  xhr.onerror = function() {
    //window.location.href = currentURL;
    console.log(this.responseText);
    //alert(this.responseText);
    //var create_status = document.getElementById("create-status");
    //create_status.setAttribute("style","display:block;")
    //create_status.innerHTML = this.responseText
  }
  xhr.send(data);
}

function hideElements(fields) {
  for (const val of fields) {
    document.getElementById(val).style.display = "none";
  }
}