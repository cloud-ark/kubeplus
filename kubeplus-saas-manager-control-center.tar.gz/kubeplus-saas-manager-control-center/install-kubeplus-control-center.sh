#!/bin/bash

KUBEPLUS_HOME=`pwd`
export KUBEPLUS_HOME=$KUBEPLUS_HOME

#os=`grep PRETTY_NAME= /etc/os-release | sed 's/=/ /'g | sed 's/"//'g | awk '{print $2}'`
os=`uname -a | awk '{print $1}'`
#echo "Operating system found: $os"

if [[ $os == "Ubuntu" ]]; then
	sudo apt-get update 
	DEBIAN_FRONTEND=noninteractive sudo apt-get install -y tzdata python3-pip curl wget tar apt-transport-https ca-certificates socat python-yaml vim gnupg lsb-release xorg-x11-xauth

	# Install kubectl
	echo "Installing kubectl..."
	curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
	sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

	# Install docker
	echo "Installing docker..."
	curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
	echo \
	  "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
	  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
	sudo apt-get update
	sudo apt-get install -y docker-ce docker-ce-cli containerd.io
	sudo usermod -aG docker $USER

fi

# Install KubePlus kubectl plugins
#wget https://github.com/cloud-ark/kubeplus/raw/master/kubeplus-kubectl-plugins.tar.gz
#gunzip kubeplus-kubectl-plugins.tar.gz
#tar -xvf kubeplus-kubectl-plugins.tar
echo "export KUBEPLUS_HOME=`pwd`" >> ~/.bashrc
echo "export KUBEPLUS_HOME=`pwd`" >> ~/.bash_profile
export PATH=$KUBEPLUS_HOME/plugins/:$PATH
echo "export PATH=$PATH" >> ~/.bashrc
echo "export PATH=$PATH" >> ~/.bash_profile
#source ~/.bashrc

echo -e "Choose username for control center>\c"
read -e username

echo -e "Choose password for control center>\c"
read -e password

mkdir -p "$HOME/.kubeplus/"
echo "$username":"$password" >> "$HOME/.kubeplus/creds"


if [[ $os == "Ubuntu" ]]; then
	echo "----------------------------------------------------------------"
	echo "Exit the VM and log back in for the installation to take effect."
fi


if [[ $os == "Darwin" ]]; then
	echo "----------------------------------------------------------------"
	echo "Make sure that Docker cli and kubectl cli are installed and you are "
	echo "able to access them without sudo."
fi

echo "----------------------------------------------------------------"
echo "Start control center as follows:"
echo "./start-control-center.sh"



