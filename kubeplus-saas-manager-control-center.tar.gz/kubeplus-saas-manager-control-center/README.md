KubePlus SaaS Manager Control Center
======================================

1. Install
   
   ``$ . ./install-kubeplus-control-center.sh``

2. Start Control Center

	``$ ./start-control-center.sh``

3. Stop Control Center

	``$ ./stop-control-center.sh``

4. Check logs

	``$ cd portal``
	```$ tail -f log.out```


Troubleshooting:
-----------------
KubePlus SaaS Manager Control Center uses ``$HOME/.kubeplus`` folder for its
operational storage. Look into that folder to identify the
the various components that are created in that run of the control
center. Check those components for troubleshooting purpose.

