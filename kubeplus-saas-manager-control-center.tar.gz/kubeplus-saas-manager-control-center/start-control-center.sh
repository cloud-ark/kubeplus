#!/bin/bash

# Pull images
echo "Pulling control center Docker images..."
docker pull gcr.io/cloudark-kubeplus/commandrunner:0.6
docker pull gcr.io/cloudark-kubeplus/prometheus-manager:0.22

# Run the prometheus manager
echo "Starting the Prometheus container..."
mkdir -p ~/.kubeplus
containerId=`docker run -P --network host -v ~/.kubeplus/:/root/.kube -v ~/.kubeplus/:/prometheus-2.27.1.linux-amd64/consoles -d gcr.io/cloudark-kubeplus/prometheus-manager:0.22`
echo $containerId >> ~/.kubeplus/monitoring-container.txt
echo $containerId

# Start AlertManager
#docker exec -d $containerId /alertmanager-0.23.0.linux-amd64/alertmanager
#docker exec -d $containerId ./alertmanager-0.23.0.linux-amd64/alertmanager --config.file=/root/alertmanager.yml --cluster.listen-address=0.0.0.0:65534 --web.listen-address=:65533
docker exec -d $containerId ./alertmanager-0.23.0.linux-amd64/alertmanager --config.file=/alertmanager-0.23.0.linux-amd64/alertmanager.yml --cluster.listen-address=0.0.0.0:65499 --web.listen-address=:65498

# Start Prometheus
#docker exec -d $containerId /prometheus-2.27.1.linux-amd64/prometheus --web.enable-lifecycle --config.file=/root/prometheus.yml
docker exec -d $containerId ./prometheus-2.27.1.linux-amd64/prometheus --web.enable-lifecycle --config.file=/root/prometheus.yml --web.listen-address="0.0.0.0:65500" --web.console.templates=/prometheus-2.27.1.linux-amd64/consoles --web.console.libraries=/prometheus-2.27.1.linux-amd64/console_libraries


# Run the portal
echo "Starting portal..."
cd portal
source venv/bin/activate
nohup python3 application.py >> log.out 2>&1 &
echo $! > ~/.kubeplus/portal.pid

# February 27, 2022
# Gunicorn based setup seems to be not starting the thread within application.py
# So commenting it out for now
#nohup gunicorn --bind 0.0.0.0:5002 wsgi:app &


if [[ $? == 0 ]]; then
	echo "KubePlus Control center started successfully."
	echo "Access it here: http://localhost:5002"
else
	echo "KubePlus Control center failed to start."
fi;




### Not used
#nohup ./triggerprometheus.sh $containerId &

#containerId=`docker run -P --network host -v ~/.kubeplus/:/root/.kube -v ~/.kubeplus/:/prometheus-2.27.1.linux-amd64/consoles -d gcr.io/cloudark-kubeplus/prometheus-manager:0.2`
#echo $containerId >> ~/.kubeplus/monitoring-container.txt

#while [ True ]
#do
#	sleep 10
#docker exec -d $containerId python3 /root/prometheusmanager.py 

#docker exec -d 7511078ce9cf kubectl port-forward kubeplus-deployment-6df757fd5f-8fz69 -n default 8081:8090 --kubeconfig=/root/.kube/org1/config
#done

#docker exec -it <container_id_or_name> echo "Hello from container!"
